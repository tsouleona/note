<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<H1>Hello! <?php echo $data->name; ?></H1>

</body>
</html>