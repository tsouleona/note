<?php

    $obj = new CAnimal();
    $obj -> makeNoise();
    $obj -> weight = -5 ;
    echo $obj -> weight,"<br>";
    $obj -> location = "TaiChung" ;
    echo $obj -> location,"<br>";
    
    class CAnimal{
        public $weight = 10;
        function makeNoise(){
            
            echo "Animal: .....<br>";
        }
    }

?>