# Homework: reading articles about OOP.
