<?php
  header("content-type: text/html; charset=utf-8");
  $s = '許功蓋';
  echo $s."<br>";
  echo strlen($s);//顯示字串長度 utf8長度為9
?>