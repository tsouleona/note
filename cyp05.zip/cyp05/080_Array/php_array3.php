<?php

$bloodType = array("A", "B", "AB", "O");
//$bloodType[3]="xy"; //會把陣列3覆蓋
for ($i = 0; $i <= 3; $i++) {
	echo $bloodType[$i] . "<br />";
}

?>
