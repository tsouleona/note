<?php
	$a = -5;
	if ($a > 0) { //如果成立則執行下面條件
		echo '$a is positive.';
	} 
	else {//若不為if的條件則跳到這邊並執行下面動作
		echo '$a is negative';
	}
?>