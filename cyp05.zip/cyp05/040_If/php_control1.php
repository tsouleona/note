<?php
	$a = 100;
	if ($a > 0) { //$a>0條件成立則執行下面動作， >0   $a is positive
		echo '$a is positive.';
	}
?>