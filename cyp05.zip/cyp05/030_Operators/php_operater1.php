<?php
	$a = "I love ";
	$b = "you";
	echo $a . $b;
?> 
