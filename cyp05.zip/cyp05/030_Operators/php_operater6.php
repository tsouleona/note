<?php
	$a = 100;
	$b = ($a > 0) ? "positive" : "negative"; // if $a>0 ans=positive
											 // else    ans=negative
	echo $b;
?>
