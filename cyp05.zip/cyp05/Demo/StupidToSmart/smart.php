<html>
<head>
<title>Lab</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
Hello! PHP
<HR>今天是： <?php echo date("Y-m-d"); ?>
</body>
</html>
