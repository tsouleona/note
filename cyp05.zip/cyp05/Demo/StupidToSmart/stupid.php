<?php 
header("content-type: text/html; charset=utf-8");
echo "<HTML>";
echo "<BODY>";
echo "Hello! PHP";
echo "<HR>今天是：";
echo date("Y-m-d");
echo "</BODY>";
echo "</HTML>";
?>
