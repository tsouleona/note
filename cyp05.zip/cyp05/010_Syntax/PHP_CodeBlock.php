<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lab</title>
</head>
<body>

<?php 
  // It's PHP code block.
  
  $x = 3;
  
  echo $x;
  
  // 區分大寫小寫
  // echo $X;

?>

</body>
</html>