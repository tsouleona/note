<?php
  define("test", 123);//定義 test 為 123
  echo test, "<br>";
  
?>
