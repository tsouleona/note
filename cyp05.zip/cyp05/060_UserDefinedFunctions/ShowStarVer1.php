<?php
function ShowStar()
{
	echo "*****";
}

ShowStar();
?>