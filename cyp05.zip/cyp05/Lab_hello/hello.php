<!DOCTYPE html>
<?php session_start();?>
<html>

<head>
    <meta charset="UTF-8">
    <title>判斷、防呆</title>
</head>

<body>
    <?php
    //header("Content-Type:text/html; charset=utf-8");
    $_SESSION["username"]=$_POST["uname"];
    $id = $_SESSION["username"];
    $pass = $_POST["upass"];
    $phone = $_POST["uphone"];
    $li=["leona","1234"];
    
    if($id==NULL || $id != $li[0])
    {
        
        echo '<meta http-equiv="refresh" content="2;url=index.php">';
        echo "<h3>登入失敗 error your Username.</h3>";
      
    }
    if($pass != $li[1] && $phone == NULL && $id == $li[0])
    {
        
        echo '<meta http-equiv="refresh" content="2;url=index.php">';
        echo "<h3>登入失敗  error your Password and your phone.</h3>";
      
    }
    if($pass != $li[1] && $phone != NULL && $id == $li[0])
    {
        
        echo '<meta http-equiv="refresh" content="2;url=index.php">';
        echo "<h3>登入失敗  error your Password.</h3>";
      
    }
    if($pass == $li[1] && $phone == NULL && $id == $li[0]){
        
        echo '<meta http-equiv="refresh" content="2;url=index.php">';
        echo "<h3>登入失敗 please input your Phone.</h3>";
    }
    if($pass == $li[1] && $phone != NULL && $id == $li[0])
    {
        echo '<meta http-equiv="refresh" content="2;url=oklogin.php">';
        echo "<h3>登入成功!!</h3>";
    }
?>
</body>

</html>