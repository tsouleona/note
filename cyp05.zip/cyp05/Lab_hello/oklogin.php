<!DOCTYPE html>
<?php session_start();?>
<html>
<head>
    <meta charset="UTF-8">
    <title>歡迎加入</title>
</head>
<body>
    
    <h3><?php echo $_SESSION["username"];?>歡迎加入本網站會員</h3>
    
</body>
</html>