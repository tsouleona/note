<!DOCTYPE html>
<?php session_start();
$phone=" ";
/*if($_POST["btnok"])
    {
        if($_POST["uname"]!=NULL )
        {
            $_SESSION["username"] = $_POST["uname"];
            header("location:hello.php");
        }
            
   }
   $phone = $_POST["uphone"];
   //include 即複製貼上，建議使用 include_once
   //require 類似include但是執行失敗時，則整個程式無法再執行
   */
?>
<html>
<head>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <meta charset="UTF-8">
    <title>登入帳號密碼</title>
</head>
<body>
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4"   class="container">
            <form method="POST" action="hello.php">
                <div class="input-group">
                  <span class="input-group-addon" id="basic-addon3">Username</span>
                  <input type="text" name="uname" class="form-control" id="basic-url" aria-describedby="basic-addon3">
                </div>
                </br>
                <div class="input-group">
                  <span class="input-group-addon" id="basic-addon3">Password</span>
                  <input type="text" name="upass" class="form-control" id="basic-url" aria-describedby="basic-addon3">
                </div>
                </br>
                <div class="input-group">
                  <span class="input-group-addon" id="basic-addon3">Phone</span>
                  <input type="text" name="uphone" class="form-control"  id="basic-url" aria-describedby="basic-addon3">
                </div>
                </br>
                <div class="col-md-6"></div>
                <input type="submit" class="btn btn-primary"name="btnok" value="OK"></input>
            
            </from>
            <!--<form method="POST" >
                <div class="input-group">
                  <span class="input-group-addon" id="basic-addon3">Username</span>
                  <input type="text" name="uname" class="form-control" id="basic-url" aria-describedby="basic-addon3">
                </div>
                </br>
                <div class="input-group">
                  <span class="input-group-addon" id="basic-addon3">Password</span>
                  <input type="text" name="upass" class="form-control" id="basic-url" aria-describedby="basic-addon3">
                </div>
                </br>
                <div class="input-group">
                  <span class="input-group-addon" id="basic-addon3">Phone</span>
                  <input type="text" name="uphone" class="form-control" value="<?php //echo $_POST["uphone"];?>" id="basic-url" aria-describedby="basic-addon3">
                </div>
                </br>
                <div class="col-md-6"></div>
                <input type="submit" class="btn btn-primary"name="btnok" value="OK"></input>
                
            </from>-->
        </div>
    </div>
   
</body>
</html>