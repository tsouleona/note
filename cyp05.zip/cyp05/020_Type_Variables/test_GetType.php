<?php
  $x = 123;
  echo gettype($x), "<br>"; //integer
  
  $x = 123.0;
  echo gettype($x), "<br>";//doudle

  $x = "123.0";
  echo gettype($x), "<br>";//string
  
  $x = TRUE;
  echo gettype($x), "<br>";//boolean
  
?>
