<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<script src="jquery.min.js"></script>
</head>
<body>

<!--
 
畫面左右各有一個下拉式選單，
左邊的下拉式選單若選擇  A 這項時，右邉的下拉式選單要改成 A01, A02, A03, A04, A05;
左邊的下拉式選單若改選  B 這項時，右邉的下拉式選單要改成 B01, B02, B03, B04, B05;
左邊的下拉式選單若改選  C 這項時，右邉的下拉式選單要改成 C01, C02, C03, C04, C05

-->

	
	
	
	<form method="post" action="http://exec.hostzi.com/echo.php">
		<select name="letter" id="letter">
			<option value="0">A</option>
			<option value="1">B</option>
			<option value="2">C</option>
		</select>&nbsp;|&nbsp; 
		<select name="letterNumber" id="letterNumber">
			<option value="0"></option>
			<option value="1"></option>
			<option value="3"></option>
			<option value="4"></option>
			<option value="5"></option>
		</select> 
		<input type="submit" id="btn"  value="OK" /> 
		<div id="debug" ></div>
	</form>
	
	<script>
		//letter option:selected input[name='rdoCity']:checked
		$("#letter").change(function(){
			X=$("#letter option:selected").text();
			url ="getLetterNumber.php?letter=" + X;
			$.get(url,function(data){
				$("#letterNumber").html(data);
			});
		});	
		$("#letter").trigger("change");//觸發被選元素指定事件類型
	</script>
	
	
</body>
</html>