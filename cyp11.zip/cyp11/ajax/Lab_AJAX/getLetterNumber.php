<?php
$result = "";
if (!isset($_GET["letter"])) {
	die("no letter found.");
}
$letter = $_GET["letter"];
$a="0";
for ($i = 0; $i < 5; $i++) {
	$result .= sprintf("<option value='%s'>%s$a%s</option>", $i, $letter, $i+1); 
}

echo $result;
?>