<?php
	include("mysql_connect.inc.php");
	
	$ord_number	= $_GET['ord_num'];
	
	$pro_num = $_GET['pro_num'];
	
	$sql = "update `order_products` set `pro_state`='缺貨中' WHERE `pro_number` = '". $pro_num ."' and `order_number`='".$ord_number."'  ;";
	mysql_query($sql);
	$sql2 = "update `order_list` set `order_state`='缺貨中' WHERE `order_number`='".$ord_number."'  ;";
	mysql_query($sql2);
	$sql3="select `s_number` from `order_list` where `order_number`='".$ord_number."'";
	$result3 = mysql_query($sql3);
	$row3 = mysql_fetch_array($result3);
	
	//$tt="s_todayview.php?ord_num='".$ord_number."'&s_num='".$row3['s_number']."'&ord_state='未確認'";

	echo '<meta http-equiv=REFRESH CONTENT=0;url=s_today.php>';
?>