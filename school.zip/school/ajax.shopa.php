<?php
	session_start();
	include("mysql_connect.inc.php");

	$pid 	= $_POST['pid'];
	$num	= $_POST['num'];
	$acc	= $_POST['acc'];
	$count 	= $_POST['count'];
	
	
	//echo $pid .' '. $count .' '. $num . ' '. $acc;
	
		/*---------------------------更新car_products-------------------------------*/
	
	
	$sql = "SELECT * FROM car_products WHERE `c_account` = '". $acc ."' AND `pro_number` = '". $pid ."'    AND `s_number` = '". $num ."'    ";
	$result = mysql_query($sql);
	$row = mysql_fetch_array($result);

	// 抓出商品單價計算總額
	$sql = "SELECT * FROM products WHERE `pro_number` = '". $pid ."'";
	$result = mysql_query($sql);
	$row2 = mysql_fetch_array($result);
	
	//print_r($row2);
	$sub_total_price = $count * $row2['price'];
	
	if(empty($row))
	{
		$sql = "INSERT INTO `car_products` (
				`c_account` ,
				`s_number` ,
				`pro_number` ,
				`price`,
				`car_quantity` ,
				`car_subtotal`
				)
				VALUES (
				'". $acc ."', '". $num ."','". $pid ."','".$row2['price']."', '". $count ."', '". $sub_total_price ."'
				);";
		mysql_query($sql);
	}
	else
	{
		$sql = "UPDATE `car_products` SET `car_quantity` = '". $count ."', `car_subtotal` = '". $sub_total_price ."' WHERE `c_account` = '". $acc ."' AND `pro_number` = '". $pid ."'  AND `s_number` = '". $num ."'  ;";
		mysql_query($sql);
	}
	
	//mysql_free_result($result);
	
	
	
	
	/*---------------------------更新car-------------------------------*/
	
	
	$sql = "SELECT * FROM car WHERE `c_account` = '". $acc ."' AND `s_number` = '". $num ."'    ";
	$result = mysql_query($sql);
	$row3 = mysql_fetch_array($result);
	
	
	
	
	// 抓出car_subtotal計算總額
	$sql = "SELECT * FROM car_products WHERE `c_account` = '". $acc ."' AND `s_number` = '". $num ."'    ";
	$result = mysql_query($sql);
	//$row_rusult4 = mysql_fetch_assoc($result);

	while($row4 = mysql_fetch_array($result))
	{
		$total_price = $total_price + $row4['car_subtotal'];
		
	}		
	
	
	
	if(empty($row3))
	{
		$sql = "INSERT INTO `car` (
				`c_account` ,
				`s_number` ,
				`car_total`
				)
				VALUES (
				'". $acc ."', '". $num ."', '". $total_price ."'
				);";
		mysql_query($sql);
	}
	else
	{
		$sql = "UPDATE `car` SET `car_total` = '". $total_price  ."' WHERE `c_account` = '". $acc ."'  AND `s_number` = '". $num ."'  ;";
		mysql_query($sql);
	}
	
	//mysql_free_result($result);
?>
