<!DOCTYPE html>
<?php 
	session_start();
	include("mysql_connect.inc.php");
?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>今日訂單 - 校園點餐網</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">


</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
         <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="s_index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li>
						<a href="s_istore.php">我的商店</a>
					</li>
					<li>
                        <a href="s_shopview.php">商家總覽</a>
					</li>
					<li>
                        <a href="s_today.php"><font color="white">今日訂單</font></a>
					</li>
					<li>
                        <a href="s_history2.php">歷史訂單</a>
					</li>
				</ul>
                <ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="s_self.php">個人設定</a>
					</li>
					<li>
						<a href="logout.php" >登出</a>
                    </li>
                </ul>
				
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		
    </nav>
	<?php
		
		
		$sql2="select * from order_list where order_number = '".$_GET['ord_num']."';";
		$result2 = mysql_query($sql2);
		$row2 = mysql_fetch_array($result2);
		$sql4="select * from c_member where c_account = '".$row2['c_account']."';";
		$result4 = mysql_query($sql4);
		$row4 = mysql_fetch_array($result4);
	
	?>
	<div class="row" style=" text-align:center" >

		<div class="col-md-3"></div>
		<div class="col-sm-6 col-lg-6 col-md-6" >
			<div class="text-center"><h1><strong><?php echo $_GET['ord_num']?></strong></h1></div>
			<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">訂購者資訊</button>
			<br></br>
			<div class="text-center" style=" text-align:center" >
				<table class="table table-bordered">
					<thead>
						<tr>
						
							<th class="text-center">名稱</th>
							<th class="text-center">數量</th>
							<th class="text-center">單價</th>
							<th class="text-center">小計</th>
							<?php
							
							
								if( $_GET['ord_state'] == "未確認" ||$_GET['ord_state'] == "缺貨中" )
								{
							?>
							<th class="text-center">缺貨中</th>
							<?php }?>
						</tr>
					</thead>
					
						  <tbody>
						<?php 
							$sql="select * from `order_products` where `order_number` = '".$_GET['ord_num']."';";
							$result = mysql_query($sql);
							while($row = mysql_fetch_assoc($result))
							{
								$sql3="select * from `products` where `pro_number` = '".$row['pro_number']."';";
								$result3 = mysql_query($sql3);
								$row3 = mysql_fetch_assoc($result3);
						   ?>
								<tr>
									<td>
										<h5><?php echo $row3['pro_name'];?></h5>
									</td>
									<td>
										<h5><?php echo $row['order_quantity'];?></h5>	
									</td>
									<td >
										<h5><?php echo $row['price'];?></h5>
									</td>
									<td >
										<h5><?php echo $row['order_subtotal'];?></h5>
									</td>
									
								
										<?php
											if( $_GET['ord_state'] == "未確認" && $row['pro_state']!="缺貨中"  )
											{
										?>
											<td >
											<button class="btn btn-default" onclick="javascript:location.href='order_lose.php?pro_num=<?php echo $row['pro_number'];?>&ord_num=<?php echo $_GET['ord_num'];?>'">缺貨中</button>
											</td>
										<?php }?>
										<?php
											if( $_GET['ord_state'] == "缺貨中" && $row['pro_state']!="缺貨中"  )
											{
										?>
											<td >
											<button class="btn btn-default" onclick="javascript:location.href='order_lose.php?pro_num=<?php echo $row['pro_number'];?>&ord_num=<?php echo $_GET['ord_num'];?>'">缺貨中</button>
											</td>
										<?php }?>
										
										<?php 
											if($row['pro_state']=="缺貨中" && $_GET['ord_state'] == "缺貨中"){ ?>
											<td >
											<h5><?php echo $row['pro_state'];?></h5>
											</td>
										<?php }?>
										
									
									
								</tr>
					  <?php }?>	
						  </tbody>
					
				</table>
				
			</div>
			

		</div>
		
		
	</div>
	<?php 
	if( $_GET['ord_state'] == "未確認" )
	{
	?>
	<div class="row" style=" text-align:center" >
		<div class="col-sm-1 col-lg-1 col-md-1" ></div>
			<div class="col-sm-10 col-lg-10 col-md-10" >
				<button class="btn btn-default" onclick="javascript:location.href='order_ok.php?ord_num=<?php echo $_GET['ord_num'];?>'"><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>&nbsp;接受訂單</a>&nbsp;	
				<button class="btn btn-default"data-toggle="modal" data-target="#moveModal" ><span class="glyphicon   glyphicon-remove-circle " aria-hidden="true"></span>&nbsp;取消訂單</button>&nbsp;
				
			</div>
	</div>
	<?php }?>
	<br></br>
	<?php if($row2['order_state']=='未確認'){?>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<div class="thumbnail">
					<div class="text-center" class="caption">
						<h4><font color="red"><span class="glyphicon glyphicon-warning-sign" aria-hidden="true"></span></font>&nbsp;請隔5-10分鐘刷新頁面注意"訂單處理狀況"</h4></br>
						<p align="left">
							註：</br>	
							接受訂單：確認接受此訂單。</br>
							取消訂單：不接受此訂單，並填寫取消原因。</br>
							缺貨中：表示該商品目前缺貨，讓消費者重新選購。</br>
							
						</p>
					</div>
				</div>
			</div>
		</div>
		<?php }?>
	
	
	<!-- Modal -->
	<form name="targetForm1" action="order_concel.php" class="form-horizontal" method="post">
		<div class="modal fade" id="moveModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			  <div class="modal-dialog">
					<div class="modal-content">
						  <div class="modal-header">
						  <SCRIPT type="text/javascript"> 
							function check()
							{
								if(targetForm1.pro_name.value == "") 
									{
										alert("請輸入取消訂單原因");
									} 
								else targetForm1.submit();
							 }
				
							</SCRIPT>
							<h4 class="modal-title" id="myModalLabel">請輸入取消訂單原因</h4>
						  </div>
							<div class="modal-body">				  
								<div class="form-group">
									<input type="hidden" name="ord_num" value="<?php echo $_GET['ord_num'];?>">
									<input type="text" class="form-control" id="pro_name" name = "why" placeholder="EX:有緊急狀況終止營業">
								</div>
							</div>
						  <div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon   glyphicon-remove " aria-hidden="true"></span>&nbsp;取消</button>
							<input type="button" class="btn btn-default"   value="確定"  onclick="check()" />	
						  </div>
					</div>
					
			  </div>
		  
		</div>
		<SCRIPT type="text/javascript"> 
			function submit()
			{
				   
				targetForm1.submit();
			}		
		</SCRIPT>
			
	</form>
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			  <div class="modal-dialog">
					<div class="modal-content">
						  <div class="modal-header">
							<h4 class="modal-title" id="myModalLabel">訂購者資訊</h4>
						  </div>
							<div class="text-center" class="modal-body">
							    					
								<div class="form-group">
									<h4><span class="glyphicon   glyphicon-user " aria-hidden="true"></span>&nbsp;<?php echo $row4['c_name']?></h4>
								</div>
														
								<div class="form-group">
									<h4><span class="glyphicon   glyphicon-credit-card " aria-hidden="true"></span>&nbsp;<?php echo $row4['c_account']?></h4>
								</div>
														
								<div class="form-group">
									<h4><span class="glyphicon glyphicon-phone" aria-hidden="true"></span>&nbsp;<?php echo $row4['c_phone']?></h4>
								</div>
							</div>
						  <div class="modal-footer">
							<button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
						  </div>
					</div>
					
			  </div>
		  
		</div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
