<?php
	session_start();
	include("mysql_connect.inc.php");
	
	    $pro_number = $_GET['num'];
		$s_acc = $_GET['s_acc'];
		
		$sql = "select * from products where pro_number = '$pro_number'";
		$result = mysql_query($sql);
		$row = @mysql_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>我的商店 - 逢甲大學點餐網</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">
	<script type="text/javascript" src="js/jquery-1.8.3.min.js" charset="UTF-8"></script>
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>


<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="s_index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    
					<li>
						<a href="s_istore.php"><font color="white">我的商店</font></a>
					</li>
					<li>
                        <a href="s_shopview.php">商家總覽</a>
					</li>
					<li>
                        <a href="s_today.php">今日訂單</a>
					</li>
					<li>
                        <a href="s_history2.php">歷史訂單</a>
					</li>
				</ul>
                <ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="s_self.php">個人設定</a>
					</li>
					
					<li>
						<a href="logout.php" >登出</a>
					</li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		
		<!--<div class="col-md-4 col-md-offset-7">
			<div class="input-group">
				<input type="text" class="form-control" placeholder="請輸入關鍵字">
				<span class="input-group-btn">
					<button class="btn btn-default" type="button">
						<span class="glyphicon glyphicon-search"></span> 搜尋商店
					</button>
				</span>
			</div>
		</div>-->
    </nav>				
	
	<?php
			$sql2 ="select * from s_member where s_account = '$s_acc' ";
			$result2 = mysql_query($sql2);
			$row2 = @mysql_fetch_assoc($result2);
		
	?>
		
			<div class="container" id="mainPage">
				<div class="col-sm-4 col-lg-4 col-md-4">
					<form name="targetForm1" action="ajax.s_istore.item.updata.php" class="form-horizontal" method="post">
					<h3 >請輸入新的商品內容</h3>
						
						<label class="radio-inline">
						  名稱
						</label>
					  <div class="form-group">
						<label for="exampleInputName2"></label>
						<input type="text" class="form-control" id="exampleInputName2" name="pro_name" placeholder="<?php echo $row['pro_name']?>">
					  </div>
					
					</br>
					
						<label class="radio-inline">
						  價錢
						</label>
					  <div class="form-group">
						<label for="exampleInputName2"></label>
						<input type="text" class="form-control" id="exampleInputName2" name = "price" placeholder="<?php echo $row['price']?>">
					  </div>
						
						
					  <div class="modal-footer">
						<a type="button" href='s_istore.php' class="btn btn-danger" ><span class="glyphicon glyphicon-floppy-remove " aria-hidden="true"></span>&nbsp;取消</a>
						<input onclick ="submit()" type="button" class="btn btn-success" value="儲存">
					  </div>
					
				  
				</div>
			</div>	
			
			<script type="text/javascript"> 
				function submit()
				{
					   
					targetForm1.submit();
				}		
				</script>
			
		</form>
		
    </div>
    
	
    
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
