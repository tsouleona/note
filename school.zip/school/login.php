<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>登入 - 校園點餐網</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/shop-homepage.css" rel="stylesheet">

</head>

<body>
     <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">

                <a class="navbar-brand" href="login.php">逢甲大學點餐網</a>
            </div>
		</div>
	</nav>
	

	
	
	

	<div class="col-md-4"></div>
	<div class="col-md-4">
		<h2>會員登入</h2>
		
		<script type="text/javascript"> 
			function check()
			{
				if(targetForm.id.value == "") 
					{
							alert("尚未輸入帳號");
					}   
				else if(targetForm.pw.value == "")
					{
							alert("尚未輸入密碼");
					}
		   
				else targetForm.submit();
			 }
				
		</script>
	
	
		<form name="targetForm" action="connect.php" class="form-horizontal" method="post">
		<div class="row">
			<div class="col-md-12">
				<section id="loginForm">
				
					<hr />
					<div class="form-group">
						<label class="col-md-2 control-label" for="id">NID帳號</label>
						<div class="col-md-10">
							<input class="form-control"  name="id" type="text"  />
							
						</div>
					</div>
					<div class="form-group">
						<label class="col-md-2 control-label" for="pw">NID密碼</label>
						<div class="col-md-10">
							<input class="form-control"  name="pw" type="password" />
						
						</div>
					</div>
					
			
			</div>
		</div>
			<div class="form-group">
				<div class="text-center">
					<ul class="nav nav-tabs nav-stacked">
					
						<input type="button" class="btn btn-default" value="下一步" name = "ok"  onclick="check()"   /> 
						<br></br>
						<!--<input  type="submit" value="登入"  />-->
						
						
					</ul>
				</div>
			</div>
		</form>
		</div>
	</div>

	
	
	<div class="col-md-4"></div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>