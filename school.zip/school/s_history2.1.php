<!DOCTYPE html>
<?php
	session_start();
	include("mysql_connect.inc.php");
?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>歷史訂單 - 校園點餐網</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">
	<!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery-1.8.3.min.js" charset="UTF-8"></script>

</head>

<body>

    <!-- Navigation -->
     <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="s_index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li>
						<a href="s_istore.php">我的商店</a>
					</li>
					<li>
                        <a href="s_shopview.php">商家總覽</a>
					</li>
					<li>
                        <a href="s_today.php">今日訂單</a>
					</li>
					<li>
                        <a href="s_history2.php"><font color="white">歷史訂單</font></a>
					</li>
					
				</ul>
                <ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="s_self.php">個人設定</a>
					</li>
					<li>
						<a href="logout.php" >登出</a>
                    </li>
                </ul>
				
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		
    </nav>
	<?php
		$id = $_SESSION['s_account'];
		$y1=$_POST['y1']; //開始的年份
		$op=$_POST['op']; //開始的月份
		$op2=$_POST['op2'];//開始的日期
		$y2=$_POST['y2']; //結束的年份
		$op3=$_POST['op3'];//結束的月份
		$op4=$_POST['op4'];//結束的日期
		//$y=date("Y",mktime($H =date('H')+8, $I =date('i')));
		$u="-";
		$str1=$y1.$u.$op.$u.$op2;
		$str2=$y2.$u.$op3.$u.$op4;
		
	?>
	</br></br>	
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-sm-6 col-lg-6 col-md-6" >
			
				<div class="text-center" >
					<table class="table table-bordered">
						
						  <thead>
							<tr>
							
							  <th class="text-center">日期</th>
							  <th class="text-center">訂單編號</th>
							  <th class="text-center">總計</th>
							  
							  
							  
							</tr>
						  </thead>
						  <tbody>
						  <?php
								$sql="select * from s_member where s_account='".$id."'";
								$result = mysql_query($sql);
								$row = mysql_fetch_assoc($result);
								
								$sql2="select * from `order_list` where `date` between '".$str1."' and '".$str2."' and `s_number`='".$row['s_number']."' and `order_state` !='未確認' and `order_state` !='缺貨中' and `order_go`='已付款' ORDER BY `date` DESC;";		
								$result2 = mysql_query($sql2);
								
						    while($row2 = mysql_fetch_assoc($result2)){
								
							
							?>
								<tr>
									<td>
										<h5><?php echo $row2['date'];?></h5>
									</td>
									<td><a  href="s_historyview.php?ord_num=<?php echo $row2['order_number'];?>&order_total=<?php echo $row2['order_total'];?>"><h5><?php echo $row2['order_number'];?></h5></a></td>
									
									<td >
										<h5><?php echo $row2['order_total'];?></h5>
									</td>
									
									
								</tr>
								
								<?php
								if($row2['order_state']!='不接受')
								{
									$total= $total+$row2['order_total'];
								}
								?>
								
						<?php }?>	
						  </tbody>
					</table>
					
				</div>
				<div class="row">
					<div class="col-md-4"></div>
					<div class="col-md-5">
						<div class="row">
						<?php
							if($total=='')
							{
								$total='0';
							}
						?>
						<h4 class="pull-right">總計：<span class="glyphicon glyphicon-usd" aria-hidden="true"></span>&nbsp;<?php echo $total ;?></h4></br>
						</div>
						
					</div>
				
			    </div>
			<div class="row">
				<div class="col-md-4"></div>
				<div class="col-md-4">
					<div class="thumbnail">
						<div class="text-center" class="caption">
							
							<p align="left">
								註：</br>
								完成交易的訂單才會出現在歷史訂單頁面。</br>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>

		
	</div>
	
	
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
