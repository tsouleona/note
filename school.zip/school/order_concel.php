<?php
	include("mysql_connect.inc.php");
	
	$ord_number	= $_POST['ord_num'];
	$why = $_POST['why'];
	
		$sql = "update `order_list` set `order_state`='不接受',`note`='".$why."' WHERE `order_number` = '". $ord_number ."' ;";
		mysql_query($sql);
		echo '<meta http-equiv=REFRESH CONTENT=0;url=s_today.php>';
	
	
?>