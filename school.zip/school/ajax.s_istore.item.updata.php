<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
	session_start();
	include("mysql_connect.inc.php");
	$id = $_SESSION['s_account'];
	$sql = "select products.pro_number from products,s_member where products.s_number=s_member.s_number and s_member.s_account ='$id' "; 
	//echo mysql_errno() . ": " . mysql_error(). "\n" ;
	
	$row_result = mysql_query($sql);
	$row  = mysql_fetch_assoc($row_result);
	
	$pro_number = $row['pro_number'];
	$pro_name	= $_POST['pro_name'];
	$price = $_POST['price'];
	
	
	if($_SESSION['s_account'] != null )
{
        $id = $_SESSION['s_account'];
		if($pro_name!=NULL)
		{
			$sql2 = "UPDATE `products` SET `pro_name`='".$pro_name."' where `pro_number`='".$pro_number."' ; ";
		}
		if($price!=NULL)
		{
			$sql2 = "UPDATE `products` SET `price`='".$price."' where `pro_number`='".$pro_number."' ; ";
		}
        //更新資料庫資料語法
        
	
		mysql_query($sql2);
        if(mysql_query($sql))
        {	
                //echo '<h1></strong>修改成功!</h1></strong>';
				//echo '<meta http-equiv=REFRESH CONTENT=0;url=s_self.php>';
				echo '<meta http-equiv=REFRESH CONTENT=0;url=s_istore.php>';
        }
        else
        {
                echo '<h1><strong>修改失敗!</h1></strong>';
                echo '<meta http-equiv=REFRESH CONTENT=1;url=s_istore.php';
        }
}
else
{
	  echo '<strong><h1>請重新登入!</h1></strong>';
	  echo '<meta http-equiv=REFRESH CONTENT=1;url=login.php>';
	
}
	
	
	
	//echo json_decode('OK');


?>