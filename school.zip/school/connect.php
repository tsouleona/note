<?php session_start(); ?>
<!--上方語法為啟用session，此語法要放在網頁最前方-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
//連接資料庫
//只要此頁面上有用到連接MySQL就要include它
include("mysql_connect.inc.php");
$id = $_POST['id'];
$pw = $_POST['pw'];


//搜尋資料庫資料
if($id[0] == "D")
{
	$sql = "SELECT * FROM c_member where c_account = '$id'";
}
if($id[0] == "S")
{
	$sql = "SELECT * FROM s_member where s_account = '$id'";
}
$result = mysql_query($sql);
$row = @mysql_fetch_row($result);

//判斷帳號與密碼是否為空白
//以及MySQL資料庫裡是否有這個會員

if($id != null && $pw != null && $row[0] == $id && $row[1] == $pw)
{
		
        //將帳號寫入session，方便驗證使用者身份
        //$_SESSION['c_account'] = $id;
		
		if($id[0] == "D")
		{
			$_SESSION['c_account'] = $id;
			echo '<meta http-equiv=REFRESH CONTENT=0;url=rule.php>';
		}
        if($id[0] == "S")
		{
			$_SESSION['s_account'] = $id;
			echo '<meta http-equiv=REFRESH CONTENT=0;url=s_rule.php>';
		}
}
else
{

        echo '<strong><h1>帳號密碼錯誤</h1></strong>';
        echo '<meta http-equiv=REFRESH CONTENT=1;url=login.php>';
}
?>