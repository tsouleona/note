<?php
	include("mysql_connect.inc.php");

	//$pid 	= $_POST['pid'];
	$acc	= $_GET['c_acc'];
	$pro_num = $_GET['pro_num'];
	
	//echo $acc;
	//echo $pro_num;
	
	$sql2 = "DELETE FROM `favorite` WHERE `c_account` = '". $acc ."' AND `pro_number` = '". $pro_num ."'    ";
	mysql_query($sql2);
	
	echo '<meta http-equiv=REFRESH CONTENT=0;url=favorite.php>';
	//echo json_decode('OK');
?>