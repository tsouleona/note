<?php
	include("mysql_connect.inc.php");

	
	$ord_number	= $_GET['ord_num'];
	

	
	$sql = "update `order_list` set `order_state`='已接受' WHERE `order_number` = '". $ord_number ."' ;";
	mysql_query($sql);
	
	echo '<meta http-equiv=REFRESH CONTENT=0;url=s_today.php>';
	
?>