<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
include("mysql_connect.inc.php");


$s_num = $_POST['s_num'];
$date = $_POST['date'];
$time = $_POST['time'];
$radio = $_POST['Radio'];
$note = $_POST['note'];

$id = $_SESSION['c_account'];

$date2 = substr($date,-4);

if($radio=="1")
{
	$word_way="外送";	
}
else
{
	$word_way="自取";
}


//echo  $date;
//echo  $time;



$sql = "SELECT MAX( order_number ) FROM `order_list` where `s_number` = '".$s_num."' AND `date` ='".$date."' ";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);

$sql2 = "SELECT * FROM car where s_number = '$s_num' and `c_account`='$id' ";
$result2 = mysql_query($sql2);
$row2 = mysql_fetch_assoc($result2);

$sql3 = "SELECT * FROM car_products where s_number = '$s_num' and `c_account`='$id' ";
$result3 = mysql_query($sql3);
//$row3 = mysql_fetch_assoc($result3);


//echo $row3['s_name'];


	if(isset($row[0]))
	{
		$max = (int)(substr($row[0], 6, 4)) + 1;
	}
		
	else
	{
		$max = 1;
	}
		
	
	
	
	//訂單編號
	$order = sprintf($s_num  . $date2 ."%04d", $max);

	$sql6 = "INSERT INTO `order_list` (
			`order_number` ,
			`s_number` ,
			`c_account` ,
			`date` ,
			`order_total` ,
			`service_way` ,
			`order_state`,
			`note`
			)
			VALUES (
			'". $order ."', '". $s_num ."', '". $id ."', '". $date ."', '". $row2['car_total'] ."', '". $word_way ."','未確認','".$note."');";
	mysql_query($sql6);
	
	while($row3 = mysql_fetch_assoc($result3)){
		
	$sql5 = "INSERT INTO `order_products` (
			`order_number` ,
			`s_number` ,
			`pro_number` ,
			`price`,
			`order_quantity` ,
			`order_subtotal` ,
			`pro_state`
			)
			VALUES (
			'". $order ."', '". $s_num ."', '". $row3['pro_number'] ."','".$row3['price']."','".$row3['car_quantity']."', '". $row3['car_subtotal'] ."','');";
	mysql_query($sql5);		
	
	$sql7 = "select * from `products` where `pro_number` = '".$row3['pro_number']."' ;";
	$result7=mysql_query($sql7);
	$row7 = mysql_fetch_assoc($result7);
	
	$temp = $row3['car_quantity'];
	$count = $row7['count'] ;
	$count = $count + $temp;
	
	$sql8 = "update `products` set `count`='".$count."' where `pro_number` = '".$row3['pro_number']."';";
	mysql_query($sql8);			
	
	
	}
	/*if($radio=="1")
	{
		$sql2 = "INSERT INTO `take_out` (
					`order_number` ,
					`take_out_note`
					)
					VALUES (
					'". $order ."', '". $note ."'
					);";
			mysql_query($sql2);
	}*/
    
$sql3="DELETE from `car_products` where `c_account`='".$id."' and `s_number`='".$s_num."'";
mysql_query($sql3);	

$sql4="DELETE from `car` where `c_account`='".$id."' and `s_number`='".$s_num."'";
mysql_query($sql4);	

echo '<meta http-equiv=REFRESH CONTENT=0;url=shopcar.php>';
?>