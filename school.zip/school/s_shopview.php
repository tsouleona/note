<?php 
	session_start();
	include("mysql_connect.inc.php");
	
	switch($_GET['status'])
	{
		case 'on':
			$status = " WHERE status = '營業中'";
			break;
		case 'off':
			$status = " WHERE status = '休息中'";
			break;
			
		default:
			$status = "";
	}
	
	//echo $status ;
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>商家總攬 - 逢甲大學點餐網</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">
	<!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery-1.8.3.min.js" charset="UTF-8"></script>
	<script type="text/javascript">
	
    $(document).ready(
        function()
        {
			
            $('#s_on').click(
                function(event)
                {
					$(location).attr('href', 's_shopview.php?status=on');
                }
            );
            
            $('#s_off').click(
                function(event)
                {
					$(location).attr('href', 's_shopview.php?status=off');
                }
            );
			
            $('#s_all').click(
                function(event)
                {
					$(location).attr('href', 's_shopview.php');
                }
            );
        }
    );
</script>

</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="s_index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    
					<li>
						<a href="s_istore.php">我的商店</a>
					</li>
					<li>
                        <a href="s_shopview.php"><font color="white">商家總覽</font></a>
					</li>
					<li>
                        <a href="s_today.php">今日訂單</a>
					</li>
					<li>
                        <a href="s_history2.php">歷史訂單</a>
					</li>
				</ul>
                <ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="s_self.php">個人設定</a>
					</li>
					
					<li>
						<a href="logout.php" >登出</a>
					</li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		
		<!--<div class="col-md-4 col-md-offset-7">
			<div class="input-group">
				<input type="text" class="form-control" placeholder="請輸入關鍵字">
				<span class="input-group-btn">
					<button class="btn btn-default" type="button">
						<span class="glyphicon glyphicon-search"></span> 搜尋商店
					</button>
				</span>
			</div>
		</div>-->
    </nav>

    <!-- Page Content -->
    <div class="container" id="mainPage">
		</br></br>
		<div class="btn-group btn-group-justified" role="group" aria-label="...">
		  <div class="btn-group" role="group">
			<button type="button" class="btn btn-success" id="s_on">營業中</button>
		  </div>
		  <div class="btn-group" role="group">
			<button type="button" class="btn btn-danger" id="s_off">休息中</button>
		  </div>
		  <div class="btn-group" role="group">
			<button type="button" class="btn btn-primary" id="s_all">所有店家</button>
		  </div>
		</div></br>
		
		<!--店家-->
		<?php
			
			$sql = "SELECT * FROM s_member" . $status;
		//	echo $sql ;
			$result = mysql_query($sql);
		//	$row_result = @mysql_fetch_assoc($result);
			
			while($row = mysql_fetch_assoc($result))
			{
			//	print_r($row);
		?>
			<div class="col-sm-3 col-lg-3 col-md-3" id="template" name = "change" style="visibility:visiable" >
			
				<div class="thumbnail">
					<div class="text-center" class="caption">
						<?php if($row['status']=='營業中')
							{
						?>
						<h3 align="center" ><strong><font color="green"><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>&nbsp;<?php echo $row['status']; ?></h3></font>
						<?php }?>
						<?php if($row['status']=='休息中')
							{
						?>
						<h3 align="center" ><strong><font color="red"><span class="glyphicon glyphicon-ban-circle" aria-hidden="true"></span>&nbsp;<?php echo $row['status']; ?></h3></font>
						<?php }?>
						<img src="/school/photo/<?php echo $row['s_number']; ?>/<?php echo $row['s_number']; ?>.jpg"  height="150px" alt="Smiley face" style="display:block; margin:auto;">
						<a href="s_shopa.php?s_num=<?php echo $row['s_number'];?>&c_acc=<?php echo $id  ;?>"><h3>&nbsp;<strong><?php echo $row['s_name']?></strong></h3></a>
						
						<input type="hidden" name="pro_number" value="<?php echo $row_result['pro_number']; ?>">
						<h4 style="display:none">店家編號: <?php echo $row['s_number']; ?></h4>
						<p><span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></span>&nbsp;<?php echo $row['s_phone']; ?></p>
						<p><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;<?php echo $row['s_address']; ?></p>
						
					
					</div>
				</div>
			</div>
		<?php
			}
			mysql_free_result($result);
		?>
		
		
    </div>
    <!-- /.container -->

   
</body>
</html>