<?php
	include("mysql_connect.inc.php");
	session_start();
	$id=$_SESSION['s_account'];
	
	
	$sql = "update `s_member` set `status`='營業中' WHERE `s_account` = '". $id ."' ;";
	mysql_query($sql);
	
	
	echo '<meta http-equiv=REFRESH CONTENT=0;url=s_istore.php>';

?>