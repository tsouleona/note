<?php
	session_start();
	include("mysql_connect.inc.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>我的商店 - 逢甲大學點餐網</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">
	<script type="text/javascript" src="js/jquery-1.8.3.min.js" charset="UTF-8"></script>
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>

	
	<script type="text/javascript">
			$(document).ready(
			function()
			{

			}
		);
		
		function updata(p_num,s_acc)
		{
			$.post("s_istore.item.php",
			{
				p_number: p_num, 
				acc: s_acc, 
				
			},
			function(data)
			{			
				alert('OK');
			}, "json");
		}
		</script>
		
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="s_index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    
					<li>
						<a href="s_istore.php"><font color="white">我的商店</font></a>
					</li>
					<li>
                        <a href="s_shopview.php">商家總覽</a>
					</li>
					<li>
                        <a href="s_today.php">今日訂單</a>
					</li>
					<li>
                        <a href="s_history2.php">歷史訂單</a>
					</li>
				</ul>
                <ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="s_self.php">個人設定</a>
					</li>
					
					<li>
						<a href="logout.php" >登出</a>
					</li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		
		<!--<div class="col-md-4 col-md-offset-7">
			<div class="input-group">
				<input type="text" class="form-control" placeholder="請輸入關鍵字">
				<span class="input-group-btn">
					<button class="btn btn-default" type="button">
						<span class="glyphicon glyphicon-search"></span> 搜尋商店
					</button>
				</span>
			</div>
		</div>-->
    </nav>
	
	<?php
		$sql4 = "SELECT * FROM s_member WHERE  s_account='".$_SESSION['s_account']."' " ;
		$result4 = mysql_query($sql4);
		$row_result4 = @mysql_fetch_assoc($result4);
	?>
    <!-- Page Content -->
    <div class="container" id="mainPage">
		<div class="text-center"><h1><strong><?php echo $row_result4['s_name'];?></strong></h1>
			<form name="targetForm1" action="s_istore.ann.updata.php" class="form-horizontal" method="post">
				<!-- Button trigger modal -->
				<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myann">
				店家公告
				</button>
				<?php if($row_result4['status']=='休息中'){?>
				<button type="button" class="btn btn-success" onclick="javascript:location.href='istore_on.php'">
				切換為營業中
				</button>
				<?php }?>
				<!--onclick="javascript:location.href='istore_off.php'"-->
				<?php if($row_result4['status']=='營業中'){?>
				<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#notice">
				切換為休息中
				</button>
				<?php }?>
				<!-- Modal -->
					<div class="modal fade" id="myann" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h4 class="modal-title" id="myModalLabel">公告</h4>
						  </div>
						  <div class="text-center" class="modal-body">
								<?php echo $row_result4['announcement'];?>

								</br></br></br><span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></span>&nbsp;<?php echo $row_result4['s_phone']?></br>
								<span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>&nbsp;<a target="_blank" href="https://www.google.com.tw/maps/place/<?php echo $row_result4['s_address'];?>"><?php echo $row_result4['s_address'];?></a>
						  </div>
						  <div class="modal-footer">
							<button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-floppy-open " aria-hidden="true"></span>&nbsp;
							修改店家資訊
							</button>
						  </div>
						</div>
					  </div>
					</div>
					<!-- Modal -->
					<div class="modal fade" id="notice" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
							<h3 class="modal-title" id="myModalLabel"><font color="red"><span class="glyphicon glyphicon-warning-sign" aria-hidden="true"></span></font>注意</h3>
						  </div>
						  <div class="text-center" class="modal-body">
								<h4>若切換狀態為休息中，您所有訂單狀態將由系統自動更改為不接受。</h4>
						  </div>
						  <div class="modal-footer">
							<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-remove " aria-hidden="true"></span>&nbsp;取消</button>
							<button type="button" class="btn btn-success" onclick="javascript:location.href='istore_off.php'">確認</button>
						  </div>
						</div>
					  </div>
					</div>
				<!-- Modal -->
				<form name="targetForm1" action="s_istore_ann_update.php" class="form-horizontal" method="post">
					<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
						<div class="modal-content">
						  <div class="modal-header">
							<h4 class="modal-title" id="myModalLabel">儲存即完成修改</h4>
						  </div>
							<div class="modal-body">				  
								
									<label class="radio-inline">
									  店名
									</label>
									<div class="form-group">
										
										<input type="text" class="form-control" id="exampleInputName2" name = "s_name" placeholder="<?php echo $row_result4['s_name'];?>">
									</div>
								
								</br>
								
								
									<label class="radio-inline">
									  公告
									</label>
								  <div class="form-group">
									
									<input type="text" class="form-control" id="exampleInputName2" name = "s_ann"placeholder="<?php echo $row_result4['announcement'];?>">
								  </div>
								
								</br>
								
								
									<label class="radio-inline">
									  電話
									</label>
								  <div class="form-group">
									
									<input type="text" class="form-control" id="exampleInputName2" name = "s_phone" placeholder="<?php echo $row_result4['s_phone']?>">
								  </div>
								
								</br>
								
								
									<label class="radio-inline">
									  地址
									</label>
								  <div class="form-group">

									<input type="text" class="form-control" id="exampleInputName2" name = "s_addr"placeholder="<?php echo $row_result4['s_address'];?>">
								  </div>
								
							</div>
						  <div class="modal-footer">
							<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-remove " aria-hidden="true"></span>&nbsp;取消</button>
							<input type="button" class="btn btn-success"   value="儲存"  onclick="submit()" />
						  </div>
						</div>
					  </div>
					</div></br></br>
					<script type="text/javascript"> 
					
						function submit()
						{
							   
							targetForm1.submit();
						}	
						
					</script>
					
				
				</form>
		</div>
		
		<!--商品-->
		<div class="col-sm-3 col-lg-3 col-md-3">
				<div class="thumbnail">
					<div class="text-center" class="caption">
						<!-- Button trigger modal -->
						</br></br></br><button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#myModal3"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>新增餐點</button></br></br></br>
					</div>
			    </div>
        </div>
		<!--<div class="col-sm-3 col-lg-3 col-md-3">
				<div class="thumbnail">
					<div class="text-center" class="caption">
						</br></br></br><button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#upload"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>新增圖檔</button></br></br></br>
					</div>
			    </div>
        </div>-->
        
		<?php
			$sql = "select * from products where s_number = '". $row_result4['s_number'] ."' ";
			$result = mysql_query($sql);
			//$row = @mysql_fetch_assoc($result);
			
		?>
		
		<?php while($row = @mysql_fetch_assoc($result)){?>
			<div class="col-sm-3 col-lg-3 col-md-3">
				<div class="thumbnail">
					<div class="text-center" class="caption">
						<img src="/school/photo/<?php echo $row['s_number'];?>/<?php echo $row['pro_number'];?>.jpg" onerror="this.src='/school/photo/nothing.jpg'"  height="150px" alt="Smiley face" style="display:block; margin:auto;">
						<h3><?php echo $row['pro_name']?></h3>
						<input type="hidden" name="pro_number" value="<?php echo $row_result['pro_number']; ?>">
						<?php if($row['flag']=='停售'){?>
						<h3>停售</h3>
						<?php }?>
						<?php if($row['flag']!='停售'){?>
						<h3><span class="glyphicon glyphicon-usd" aria-hidden="true"></span><?php echo $row['price']?></h3>
						<?php }?>
						<?php if($row_result4['status']=='休息中' && $row['flag']=='停售'){?>
						<button class="btn btn-success" onclick="javascript:location.href='ajax.s_istore.item.sale.php?pro_num=<?php echo $row['pro_number'];?>&s_num=<?php echo $row['s_number'];?>'"><span class="glyphicon   glyphicon-ok-sign " aria-hidden="true"></span>&nbsp;販售</button>
						<?php }?>
						<?php if($row_result4['status']=='休息中' && $row['flag']!='停售'){?>
						<button class="btn btn-danger" onclick="javascript:location.href='ajax.s_istore.item.del.php?pro_num=<?php echo $row['pro_number'];?>&s_num=<?php echo $row['s_number'];?>'"><span class="glyphicon   glyphicon-remove-sign " aria-hidden="true"></span>&nbsp;停售</button>
						<?php }?>
						<?php if($row_result4['status']=='營業中' && $row['flag']=='停售'){?>
						<button class="btn btn-success" disabled="disabled"onclick="javascript:location.href='ajax.s_istore.item.sale.php?pro_num=<?php echo $row['pro_number'];?>&s_num=<?php echo $row['s_number'];?>'"><span class="glyphicon   glyphicon-ok-sign " aria-hidden="true"></span>&nbsp;販售</button>
						<?php }?>
						<?php if($row_result4['status']=='營業中' && $row['flag']!='停售'){?>
						<button class="btn btn-danger" disabled="disabled"onclick="javascript:location.href='ajax.s_istore.item.del.php?pro_num=<?php echo $row['pro_number'];?>&s_num=<?php echo $row['s_number'];?>'"><span class="glyphicon   glyphicon-remove-sign " aria-hidden="true"></span>&nbsp;停售</button>
						<?php }?>
						
						<!-- Button trigger modal -->
						<?php if($row['flag']=='停售' && $row_result4['status']=='營業中'){?>
						<button disabled="disabled" onclick="javascript:location.href='s_istore_item.php?num=<?php echo $row['pro_number'];?>&s_acc=<?php echo $_SESSION['s_account']; ?>'" type="button" class="btn btn-primary" ><span class="glyphicon glyphicon-floppy-open " aria-hidden="true"></span>&nbsp;修改內容</button>
						<?php }?>
						<?php if($row['flag']!='停售' && $row_result4['status']=='營業中'){?>
						<button disabled="disabled" onclick="javascript:location.href='s_istore_item.php?num=<?php echo $row['pro_number'];?>&s_acc=<?php echo $_SESSION['s_account']; ?>'" type="button" class="btn btn-primary" ><span class="glyphicon glyphicon-floppy-open " aria-hidden="true"></span>&nbsp;修改內容</button>
						<?php }?>
						<?php if($row['flag']!='停售' && $row_result4['status']=='休息中'){?>
						<button onclick="javascript:location.href='s_istore_item.php?num=<?php echo $row['pro_number'];?>&s_acc=<?php echo $_SESSION['s_account']; ?>'" type="button" class="btn btn-primary" ><span class="glyphicon glyphicon-floppy-open " aria-hidden="true"></span>&nbsp;修改內容</button>
						<?php }?>
						<?php if($row['flag']=='停售' && $row_result4['status']=='休息中'){?>
						<button disabled="disabled" onclick="javascript:location.href='s_istore_item.php?num=<?php echo $row['pro_number'];?>&s_acc=<?php echo $_SESSION['s_account']; ?>'" type="button" class="btn btn-primary" ><span class="glyphicon glyphicon-floppy-open " aria-hidden="true"></span>&nbsp;修改內容</button>
						<?php }?>
					</div>
				</div>
			</div>	
		<?php }?>
		
		
						<!-- Modal -->
						<form name="targetForm2" action="ajax.s_istore.item.add.php" class="form-horizontal" method="post">
							<div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-dialog">
									<div class="modal-content">
									  <div class="modal-header">
										<h4 class="modal-title" id="myModalLabel">儲存即完成新增</h4>
									  </div>
										<div class="modal-body">				  
											
												<label class="radio-inline">
												  名稱
												</label>
												<div class="form-group">
													
													<input type="text" class="form-control" id="pro_name" name = "pro_name" placeholder="請輸入新的餐點名稱">
												</div>
											
											</br>
											
											
												<label class="radio-inline">
												  價錢
												</label>
											  <div class="form-group">
												
												<input type="text" class="form-control" id="price" name = "price" placeholder="請輸入新的餐點價錢">
											  </div>
											
											</br>
										  <div class="modal-footer">
											<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-remove " aria-hidden="true"></span>&nbsp;取消</button>
											<input type="button" class="btn btn-success"   value="儲存"  onclick="submit2()" />
										
										  </div>
									   </div>
									</div>
								</div>
							</div>
									<script type="text/javascript"> 
								function submit2()
								{
									if(targetForm2.pro_name.value=="" || targetForm2.price.value=="" )
									{
										alert("商品的名稱與價錢一定要寫");
									}
									   
									else targetForm2.submit();
								}		
							</script>
			
						</form>
						
						<!-- Modal -->
						<!--<form name="targetForm2" action="upload.php" class="form-horizontal" method="post">
							<div class="modal fade" id="upload" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-dialog">
									<div class="modal-content">
									  <div class="modal-header">
										<h4 class="modal-title" id="myModalLabel">上傳圖檔</h4>
									  </div>
										<div class="modal-body">	
												<input type="hidden" name="s_number" value="<?php //echo $row['s_number'];?>">
												<h4>請輸入該圖檔為哪份餐點</h4>
												<div class="form-group">
													
													<input type="text" class="form-control" id="pro_name" name="name" value="">
												</div>
												<div class="form-group">
													
													檔案名稱:<input type="file" name="file" id="file" /><br />
													<input type="button" class="btn btn-success" onclick="submit()" value="上傳檔案" />
													<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-remove " aria-hidden="true"></span>&nbsp;取消</button>
												</div>
											
											</br>
											
											
												
									   </div>
									</div>
								</div>
							</div>
								<script type="text/javascript"> 
								function submit2()
								{
									if(targetForm2.pro_name.value=="" && targetForm2.price.value=="" )
									{
										alert("商品的名稱與價錢一定要寫");
									}
									   
									else targetForm2.submit();
								}		
							</script>
			
						</form>-->
    
	
    
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
