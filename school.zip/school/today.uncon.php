<?php
	include("mysql_connect.inc.php");

	
	$acc	= $_GET['c_acc'];
	$s_num	= $_GET['s_num'];
	$ord_num = $_GET['ord_num'];
	
	

	//echo  $num . ' '. $acc;
	$sql3 = "select * FROM `order_list` WHERE `order_number` = '". $ord_num ."'  ";
	$result3=mysql_query($sql3);
	$row3 = mysql_fetch_array($result3);
	
	$sql4 = "select * FROM `order_products` WHERE `order_number` = '". $ord_num ."'  ";
	$result4=mysql_query($sql4);
	//$row4 = mysql_fetch_array($result4);
	
	if($row3['order_state']=='不接受')
	{
		echo '<h1><strong>您的訂單為不接受狀態</strong></h1>';
		echo '<meta http-equiv=REFRESH CONTENT=2;url=today.php>';
	}
	elseif($row3['order_state']=='已接受')
	{
		echo '<h1><strong>您的訂單為已接受狀態</strong></h1>';
		echo '<meta http-equiv=REFRESH CONTENT=2;url=today.php>';
	}
	else
	{
		$sql6 = "INSERT INTO `car` (
			`c_account` ,
			`s_number` ,
			`car_total` 
			)
			VALUES (
			'". $acc ."', '". $s_num ."','".$row3['order_total']."');";
	mysql_query($sql6);
	
	while($row4 = mysql_fetch_assoc($result4)){
	$sql5 = "INSERT INTO `car_products` (
			`c_account` ,
			`s_number` ,
			`pro_number` ,
			`car_quantity` ,
			`car_subtotal` 
			)
			VALUES (
			'". $acc ."', '". $s_num ."', '". $row4['pro_number'] ."','".$row4['order_quantity']."', '". $row4['order_subtotal'] ."');";
	mysql_query($sql5);
	}

	
	$sql = "DELETE FROM `order_list` WHERE `order_number` = '". $ord_num ."' ";
	mysql_query($sql);
	
	
	$sql2 = "DELETE FROM `order_products` WHERE `order_number` = '". $ord_num ."' ";
	mysql_query($sql2);

	
	
	
	echo '<meta http-equiv=REFRESH CONTENT=0;url=shopcar.php>';
	//echo json_decode('OK');
	}
	
	
?>