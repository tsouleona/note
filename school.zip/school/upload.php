<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
session_start();
include("mysql_connect.inc.php");

$name=$_POST['name'];
$s_num=$_POST['s_number'];

$sql="select * from `products` where `s_number`='".$s_number."' ";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);

/*if ($_FILES["file"]["error"] > 0)
{
　echo "Error:".$_FILES["file"]["error"];
}
else{*/
　echo "檔案名稱: " . $_FILES["file"]["name"]."<br/>";
　echo "檔案類型: " . $_FILES["file"]["type"]."<br/>";
　echo "檔案大小: " . ($_FILES["file"]["size"] / 1024)." Kb<br />";
　echo "暫存名稱: " . $_FILES["file"][$row['s_number']];
　
　if (file_exists("/school/photo/$s_number" . $_FILES["file"]["name"])){
　　echo "檔案已經存在，請勿重覆上傳相同檔案";
　}else{
　　move_uploaded_file($_FILES["file"][$row['s_number']],"/school/photo/$s_number".$_FILES["file"]["name"]);
　}
//}
?>