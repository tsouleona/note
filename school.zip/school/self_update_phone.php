<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
include("mysql_connect.inc.php");


$phone = $_POST['c_phone'];

$id = $_SESSION['c_account'];
//若以下$id直接用$_SESSION['c_account']將無法使用
$sql = "SELECT * FROM c_member where c_account = '$id'";
$result = mysql_query($sql);
$row = mysql_fetch_row($result);



//紅色字體為判斷密碼是否填寫正確
if($_SESSION['c_account'] != null )
{
        $id = $_SESSION['c_account'];
    
        //更新資料庫資料語法
        $sql = "update c_member set  c_phone='$phone' where c_account='$id'";
        if(mysql_query($sql))
        {	
                //echo '<h1></strong>修改成功!</h1></strong>';
				//echo '<meta http-equiv=REFRESH CONTENT=1;url=self.php>';
				header("Location: self.php");
        }
        else
        {
                echo '<h1><strong>修改失敗!</h1></strong>';
                echo '<meta http-equiv=REFRESH CONTENT=1;url=self.php';
        }
}
else
{
	  echo '<strong><h1>請重新登入!</h1></strong>';
	  echo '<meta http-equiv=REFRESH CONTENT=1;url=login.php>';
	
}

?>