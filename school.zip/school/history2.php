<?php 
	session_start();
	include("mysql_connect.inc.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>歷史訂單 - 校園點餐網</title>

     <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">
    
	
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery-1.8.3.min.js" charset="UTF-8"></script>

</head>

<body>

    <!-- Navigation -->
     <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li>
                        <a href="shopcar.php">購物車</a>
					</li>
					<li>
                        <a href="favorite.php">我的最愛</a>
					</li>
					<li>
                        <a href="shopview.php">商家總覽</a>
					</li>
					<li>
                        <a href="today.php">今日訂單</a>
					<li>
                        <a href="history2.php"><font color="white">歷史訂單</font></a>
					</li>
				</ul>
                <ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="self.php">個人設定</a>
					</li>
					<li>
						<a href="logout.php" >登出</a>
                    </li>
                </ul>
				
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		
    </nav>
	

	</br></br>	
	</br></br>
	<div class="row">
		
		<div class="col-sm-4 col-lg-4 col-md-4"></div>
		<form name="targetForm1" action="history2.1.php" class="form-horizontal" method="post">
		
			<div class="col-sm-3 col-lg-3 col-md-3">
				<div  class="thumbnail">
					<div class="text-center" class="caption">
							<h3><strong>請輸入開始日期</h3></br>
							<h4>請選擇年份</h4>
							<select id="y1" name="y1">
							 <option value="" selected="true">年份</option>
							 <option value="2015">2015</option>
							 <option value="2016">2016</option>
							 <option value="2017">2017</option>
							 <option value="2018">2018</option>
							 <option value="2019">2019</option>
							 <option value="2020">2020</option>
							 <option value="2021">2021</option>
							 <option value="2022">2022</option>
							 <option value="2023">2023</option>
							 <option value="2024">2024</option>
							 <option value="2025">2025</option>
							 <option value="2026">2026</option>
							</select>
							
							<h4>請選擇月份</h4>
							<select id="op" name="op">
							 <option value="" selected="true">月份</option>
						     <option value="01">1</option>
							 <option value="02">2</option>
							 <option value="03">3</option>
							 <option value="04">4</option>
							 <option value="05">5</option>
							 <option value="06">6</option>
							 <option value="07">7</option>
							 <option value="08">8</option>
							 <option value="09">9</option>
							 <option value="10">10</option>
							 <option value="11">11</option>
							 <option value="12">12</option>
							</select>
							<br></br>
							<h4>請選擇日期</h4>
							<select id="op2" name="op2">
							 <option value="" selected="true">日期</option>
							 <option value="01">1</option>
							 <option value="02">2</option>
							 <option value="03">3</option>
							 <option value="04">4</option>
							 <option value="05">5</option>
							 <option value="06">6</option>
							 <option value="07">7</option>
							 <option value="08">8</option>
							 <option value="09">9</option>
							 <option value="10">10</option>
							 <option value="11">11</option>
							 <option value="12">12</option>
							 <option value="13">13</option>
							 <option value="14">14</option>
							 <option value="15">15</option>
							 <option value="16">16</option>
							 <option value="17">17</option>
							 <option value="18">18</option>
							 <option value="19">19</option>
							 <option value="20">20</option>
							 <option value="21">21</option>
							 <option value="22">22</option>
							 <option value="23">23</option>
							 <option value="24">24</option>
							 <option value="25">25</option>
							 <option value="26">26</option>
							 <option value="27">27</option>
							 <option value="28">28</option>
							 <option value="29">29</option>
							 <option value="30">30</option>
							 <option value="31">31</option>
							</select>
							<br></br>
							<h3><strong>請輸入結束日期</h3></br>
							<h4>請選擇年份</h4>
							<select id="y2" name="y2">
							 <option value="" selected="true">年份</option>
							 <option value="2015">2015</option>
							 <option value="2016">2016</option>
							 <option value="2017">2017</option>
							 <option value="2018">2018</option>
							 <option value="2019">2019</option>
							 <option value="2020">2020</option>
							 <option value="2021">2021</option>
							 <option value="2022">2022</option>
							 <option value="2023">2023</option>
							 <option value="2024">2024</option>
							 <option value="2025">2025</option>
							 <option value="2026">2026</option>
							</select>
							
							<h4>請選擇月份</h4>
							<select id="op3" name="op3">
							<option  value="" selected="true">月份</option>
							 <option value="01">1</option>
							 <option value="02">2</option>
							 <option value="03">3</option>
							 <option value="04">4</option>
							 <option value="05">5</option>
							 <option value="06">6</option>
							 <option value="07">7</option>
							 <option value="08">8</option>
							 <option value="09">9</option>
							 <option value="10">10</option>
							 <option value="11">11</option>
							 <option value="12">12</option>
							</select>
							<br></br>
							<h4>請選擇日期</h4>
							<select id="op4" name="op4">
							<option  value="" selected="true">日期</option>
							 <option value="01">1</option>
							 <option value="02">2</option>
							 <option value="03">3</option>
							 <option value="04">4</option>
							 <option value="05">5</option>
							 <option value="06">6</option>
							 <option value="07">7</option>
							 <option value="08">8</option>
							 <option value="09">9</option>
							 <option value="10">10</option>
							 <option value="11">11</option>
							 <option value="12">12</option>
							 <option value="13">13</option>
							 <option value="14">14</option>
							 <option value="15">15</option>
							 <option value="16">16</option>
							 <option value="17">17</option>
							 <option value="18">18</option>
							 <option value="19">19</option>
							 <option value="20">20</option>
							 <option value="21">21</option>
							 <option value="22">22</option>
							 <option value="23">23</option>
							 <option value="24">24</option>
							 <option value="25">25</option>
							 <option value="26">26</option>
							 <option value="27">27</option>
							 <option value="28">28</option>
							 <option value="29">29</option>
							 <option value="30">30</option>
							 <option value="31">31</option>
							</select>
							<br></br>
							<div class="row">
							<input type="button" onclick="check()" class="btn btn-primary" value="確定">
							</div>
					</div>
				</div>
			</div>
			<script type="text/javascript"> 
			function check()
			{
				if(targetForm1.y2.value == ""||targetForm1.y1.value == ""||targetForm1.op.value == ""||targetForm1.op2.value == ""||targetForm1.op3.value == ""||targetForm1.op4.value == "") 
					{
						alert("請輸入開始與結束月份與日期");
					} 
				else if(targetForm1.y1.value > targetForm1.y2.value )
					{
						alert("開始年份要比結束年份早");
					}
				else if(targetForm1.y1.value == targetForm1.y2.value && targetForm1.op.value > targetForm1.op3.value)
					{
						alert("開始月份要比結束月份早");
					}
				else if(targetForm1.y1.value == targetForm1.y2.value && targetForm1.op.value == targetForm1.op3.value && targetForm1.op2.value > targetForm1.op4.value)
					{
						alert("開始日期要比結束日期早");
					}
				else targetForm1.submit();
			 }
				
		</script>
		</form>
		
	</div>			      

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
