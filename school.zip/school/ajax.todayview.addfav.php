<?php
	include("mysql_connect.inc.php");

	$acc	= $_GET['c_acc'];
	$pro_num = $_GET['pro_num'];

	
	$sql2 = "INSERT INTO `favorite`(`c_account`, `pro_number`) VALUES ('".$acc."','".$pro_num."')";
	mysql_query($sql2);

	echo '<meta http-equiv=REFRESH CONTENT=0;url=today.php>';
	
?>