<?php
	include("mysql_connect.inc.php");
	session_start();
	$id=$_SESSION['s_account'];
	
	
	$sql = "update `s_member` set `status`='休息中' WHERE `s_account` = '". $id ."' ;";
	mysql_query($sql);
	
	$sql2="select * from `s_member` where `s_account` = '". $id ."'; ";
	$result2 = mysql_query($sql2);
	$row2=mysql_fetch_array($result2);
	
	if($row2['status']=='休息中')
	{
		$sql3="update `order_list` set `order_state`='不接受',`note`='店家休息' where  `s_number`='".$row2['s_number']."';";	
		mysql_query($sql3);
	}

	
	echo '<meta http-equiv=REFRESH CONTENT=0;url=s_istore.php>';

?>