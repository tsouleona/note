<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
include("mysql_connect.inc.php");

$name = $_POST['s_name'];
$ann = $_POST['s_ann'];
$phone = $_POST['s_phone'];
$addr = $_POST['s_addr'];


$id = $_SESSION['s_account'];

//若以下$id直接用$_SESSION['c_account']將無法使用
$sql = "SELECT * FROM s_member where s_account = '$id'";
$result = mysql_query($sql);
$row = mysql_fetch_row($result);

 //echo $phone;

//紅色字體為判斷密碼是否填寫正確
if($_SESSION['s_account'] != null )
{
        $id = $_SESSION['s_account'];
		
		if($name!=NULL)
		{
			$sql = "update `s_member` set `s_name` = '".$name."' where s_account='$id'";
		}
		if($ann!=NULL)
		{
			$sql = "update `s_member` set `announcement` = '".$ann."' where s_account='$id'";
		}
		if($phone!=NULL)
		{
			$sql = "update `s_member` set `s_phone` = '".$phone."' where s_account='$id'";
		}
		if($addr!=NULL)
		{
			$sql = "update `s_member` set `s_address` = '".$addr."' where s_account='$id'";
		}
		
		
    
        //更新資料庫資料語法
       // $sql = "update `s_member` set `s_name` = '".$name."',`announcement`='".$ann."',`s_phone`='".$phone."',`s_address`='".$addr."' where s_account='$id'";
        if(mysql_query($sql))
        {	
                //echo '<h1></strong>修改成功!</h1></strong>';
				//echo '<meta http-equiv=REFRESH CONTENT=0;url=s_self.php>';
				header("Location: s_istore.php");
        }
        else
        {
                echo '<h1><strong>修改失敗!</h1></strong>';
                echo '<meta http-equiv=REFRESH CONTENT=1;url=s_istore.php';
        }
}
else
{
	  echo '<strong><h1>請重新登入!</h1></strong>';
	  echo '<meta http-equiv=REFRESH CONTENT=1;url=login.php>';
	
}

?>