<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
include("mysql_connect.inc.php");



$Email = $_POST['s_Email'];

$id = $_SESSION['s_account'];
//若以下$id直接用$_SESSION['c_account']將無法使用
$sql = "SELECT * FROM s_member where s_account = '$id'";
$result = mysql_query($sql);
$row = mysql_fetch_row($result);



//紅色字體為判斷密碼是否填寫正確
if($_SESSION['s_account'] != null )
{
        $id = $_SESSION['s_account'];
    
        //更新資料庫資料語法
        $sql = "update s_member set  s_Email='$Email' where s_account='$id'";
        if(mysql_query($sql))
        {
               // echo '<strong><h1>修改成功!</h1></strong>';
				//echo '<meta http-equiv=REFRESH CONTENT=1;url=s_self.php>';
				header("Location: s_self.php");
        }
        else
        {
                echo '<h1><strong>修改失敗!</h1></strong>';
				echo '<meta http-equiv=REFRESH CONTENT=1;url=s_self.php>';
				
        }
}
else
{
	  echo '<strong><h1>請重新登入!</h1></strong>';
	  echo '<meta http-equiv=REFRESH CONTENT=1;url=login.php>';
	
	
}

?>