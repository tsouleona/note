<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>我的最愛 - 逢甲大學點餐網</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript">
		
		$(document).ready(
			function()
			{

			}
		);
		
		function add_car(p_num,c_acc,s_num)
		{
			$.post("ajax.shopa.php",
			{
				pid: p_num, //pro_number
				num: s_num, //加入購物車，接s_number
				acc: c_acc, //加入購物車，接c_account
				count: $('#' +p_num).val() //數量
			},
			function(data)
			{			
				alert('OK');
			}, "json");
		}
		
		function aa(id)
		{
			$('#' + id).attr('value', parseInt($('#' + id).val()) + 1);
		}
		
		function bb(id)
		{
			var num = 1;
			if((parseInt($('#' + id).val()) - 1) < 1 )
				num = 1;
			else 
				num = parseInt($('#' + id).val()) - 1;
				
			$('#' + id).attr('value', num);
		}
		
	</script>
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    
                    <li>
                        <a href="shopcar.php">購物車</a>
                    </li>
					<li>
                        <a href="favorite.php"><font color="white">我的最愛</font></a>
                    </li>
					<li>
                        <a href="shopview.php">商家總覽</a>
                    </li>
					<li>
                        <a href="today.php">今日訂單</a>
                    </li>
					<li>
                        <a href="history2.php">歷史訂單</a>
                    </li>
                </ul>
				<ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="self.php">個人設定</a>
                    </li>
					<li>
						<a href="logout.php" >登出</a> 
					</li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		
		<!--<div class="col-md-4 col-md-offset-7">
			<div class="input-group">
				<input type="text" class="form-control" placeholder="請輸入關鍵字">
				<span class="input-group-btn">
					<button class="btn btn-default" type="button">
						<span class="glyphicon glyphicon-search"></span> 搜尋商店
					</button>
				</span>
			</div>
		</div>-->
    </nav>

    <!-- Page Content -->
	</br></br>
	
	
	<?php
		include("mysql_connect.inc.php");
		//使用 mysql_pconnect()而不使用mysql_connect( ) 可以省下每次重新開啟資料庫連接的時間

	?>	
	<?php
		$id = $_SESSION['c_account'];
		
		$sql = "SELECT pro_name,price,favorite.pro_number,products.s_number,s_member.s_name FROM favorite,products,s_member where favorite.pro_number=products.pro_number and products.s_number=s_member.s_number and c_account = '$id'";
		$result = mysql_query($sql);
		//$row_result = @mysql_fetch_assoc($result);
		
		
	?>
    <div class="container" id="mainPage">
	
		<?php /*
			if( mysql_fetch_assoc($result)==NULL)
			{
				echo "<h1>尚未有任何商品加入我的最愛</h1>";
			}*/
		
		?>
		
		
		<!商品>
		<?php while($row_result = mysql_fetch_assoc($result)){ ?>
				<?php 
					$sql2="select status from s_member where s_number='".$row_result['s_number']."';";
					$result2 = mysql_query($sql2);
					$row2 = @mysql_fetch_assoc($result2);
					
				?>
			<div class="col-sm-3 col-lg-3 col-md-3" id="template" name = "change" style="visibility:visiable" >
			
				<div class="thumbnail">
					<div class="text-center" class="caption">
						
						<img src="/school/photo/<?php echo $row_result['s_number'];?>/<?php echo $row_result['pro_number'];?>.jpg" onerror="this.src='/school/photo/nothing.jpg'" width="150px" height="150px" alt="Smiley face" style="display:block; margin:auto;">
						
						<a href="shopa.php?s_num=<?php echo $row_result['s_number'];?>&c_acc=<?php echo $_SESSION['c_account'];?>"><h3>&nbsp;<?php echo $row_result[s_name]?></h3></a>
						<h3><?php echo $row_result['pro_name']; ?></h3>
						<input type="hidden" name="pro_number" value="<?php echo $row_result['pro_number']; ?>">
						<?php if($row_result['flag']=='停售'){?>
						<h3>停售</h3>
						<?php }?>
						<?php if($row_result['flag']!='停售'){?>
						<h3><span class="glyphicon glyphicon-usd" aria-hidden="true"></span>&nbsp;<?php echo $row_result['price']; ?><h3>
						<?php }?>
						
						<?php if($row_result['flag']=='停售' && $row2['status']!="休息中"){?>
						<button disabled="disabled" onclick=aa('<?php echo $row_result['pro_number']; ?>') class="btn btn-default" ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
						<input type="text" size="1" title="Qty" value="1" name="qty" step="1" id="<?php echo $row_result['pro_number']; ?>">
						<button disabled="disabled" onclick=bb('<?php echo $row_result['pro_number']; ?>') class="btn btn-default"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></button>
						</br></br>
						<button disabled="disabled" type="button" class="btn btn-info" data-toggle="modal" data-target="#carModal" onclick=add_car('<?php echo $row_result['pro_number']; ?>','<?php echo $_SESSION['c_account']; ?>','<?php echo $row_result['s_number']; ?>')><span class="glyphicon glyphicon-shopping-cart " aria-hidden="true"></span>&nbsp;加入購物車</button> 
						<button disabled="disabled" onclick="javascript:location.href='ajax.movefav.php?c_acc=<?php echo $_SESSION['c_account']; ?>&pro_num=<?php echo $row_result['pro_number']; ?>'"type="button" class="btn btn-warning" ><span class="glyphicon glyphicon-heart-empty" aria-hidden="true"></span>&nbsp; 移除最愛</button>
						<?php }?>
						
						<?php if($row_result['flag']=='停售' && $row2['status']!="休息中"){?>
						<button disabled="disabled" onclick=aa('<?php echo $row_result['pro_number']; ?>') class="btn btn-default" ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
						<input type="text" size="1" title="Qty" value="1" name="qty" step="1" id="<?php echo $row_result['pro_number']; ?>">
						<button disabled="disabled" onclick=bb('<?php echo $row_result['pro_number']; ?>') class="btn btn-default"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></button>
						</br></br>
						<button disabled="disabled" type="button" class="btn btn-info" data-toggle="modal" data-target="#carModal" onclick=add_car('<?php echo $row_result['pro_number']; ?>','<?php echo $_SESSION['c_account']; ?>','<?php echo $row_result['s_number']; ?>')><span class="glyphicon glyphicon-shopping-cart " aria-hidden="true"></span>&nbsp;加入購物車</button> 
						<button disabled="disabled" onclick="javascript:location.href='ajax.movefav.php?c_acc=<?php echo $_SESSION['c_account']; ?>&pro_num=<?php echo $row_result['pro_number']; ?>'"type="button" class="btn btn-warning" ><span class="glyphicon glyphicon-heart-empty" aria-hidden="true"></span>&nbsp; 移除最愛</button>
						<?php }?>
					
						
						<?php if($row_result['flag']!='停售' && $row2['status']=="休息中"){?>
						<button disabled="disabled" onclick=aa('<?php echo $row_result['pro_number']; ?>') class="btn btn-default" ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
						<input type="text" size="1" title="Qty" value="1" name="qty" step="1" id="<?php echo $row_result['pro_number']; ?>">
						<button disabled="disabled" onclick=bb('<?php echo $row_result['pro_number']; ?>') class="btn btn-default"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></button>
						</br></br>
						<button disabled="disabled" type="button" class="btn btn-info" data-toggle="modal" data-target="#carModal" onclick=add_car('<?php echo $row_result['pro_number']; ?>','<?php echo $_SESSION['c_account']; ?>','<?php echo $row_result['s_number']; ?>')><span class="glyphicon glyphicon-shopping-cart " aria-hidden="true"></span>&nbsp;加入購物車</button> 
						<button onclick="javascript:location.href='ajax.movefav.php?c_acc=<?php echo $_SESSION['c_account']; ?>&pro_num=<?php echo $row_result['pro_number']; ?>'"type="button" class="btn btn-warning" ><span class="glyphicon glyphicon-heart-empty" aria-hidden="true"></span>&nbsp; 移除最愛</button>
						<?php }?>
						
						
						
						<?php if($row_result['flag']!='停售' && $row2['status']!="休息中" ){?>
						<button onclick=aa('<?php echo $row_result['pro_number']; ?>') class="btn btn-default" ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
						<input type="text" size="1" title="Qty" value="1" name="qty" step="1" id="<?php echo $row_result['pro_number']; ?>">
						<button onclick=bb('<?php echo $row_result['pro_number']; ?>') class="btn btn-default"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></button>
						</br></br>
						<button type="button" class="btn btn-info" data-toggle="modal" data-target="#carModal" onclick=add_car('<?php echo $row_result['pro_number']; ?>','<?php echo $_SESSION['c_account']; ?>','<?php echo $row_result['s_number']; ?>')><span class="glyphicon glyphicon-shopping-cart " aria-hidden="true"></span>&nbsp;加入購物車</button> 
						<button onclick="javascript:location.href='ajax.movefav.php?c_acc=<?php echo $_SESSION['c_account']; ?>&pro_num=<?php echo $row_result['pro_number']; ?>'"type="button" class="btn btn-warning" ><span class="glyphicon glyphicon-heart-empty" aria-hidden="true"></span>&nbsp; 移除最愛</button>
						<?php }?>
						
					</div>
				</div>
			</div>
			
		<?php } ?>
		
		
		
    </div>
	<!-- Modal -->
				<div class="modal fade" id="carModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				    <div class="modal-dialog">
						<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
								<h4 class="modal-title" id="myModalLabel">已加入購物車</h4>
							  </div>
						  
						</div>
				    </div>
				</div>
				
				<!--<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
						<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
								<h4 class="modal-title" id="myModalLabel">已加入我的最愛</h4>
							  </div>
						  
						</div>
				  </div>
				</div>-->
				<div class="modal fade" id="moveModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
						<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
								<h4 class="modal-title" id="myModalLabel">已移除我的最愛</h4>
							  </div>
						  
						</div>
				  </div>
				</div>
    
    <!-- /.container -->
</body>

</html>
