<?php
	include("mysql_connect.inc.php");

	$acc	= $_GET['c_acc'];
	$pro_num= $_GET['p_num'];
	$count  = $_GET['coun'];
	$s_number = $_GET['s_num'];
	
	//echo $s_number;
	
	$sql = " select * from `products` where  `pro_number` = '".$pro_num."' ";
	$result = mysql_query($sql);
	$row = mysql_fetch_array($result);
	
	
	$sql2 = " select * from `car` where `c_account` = '". $acc ."' AND `s_number`='".$s_number."' ";
	$result2 = mysql_query($sql2);
	$row2 = mysql_fetch_array($result2);
	
	
	
	//echo $row['price'];
	//echo $row2['car_total'];
	
	
	$temp="1";
	$count = $count+$temp;
	$subtotal = $row['price']*$count;
	$car_total = $row2['car_total'] + $row['price'];
	//echo "cartotal=";
	//echo $car_total;
	
	$sql3 = "UPDATE `car` SET `car_total` = '". $car_total ."'  WHERE `c_account` = '". $acc ."' AND `s_number`='".$s_number."'";
	mysql_query($sql3);
	$sql4 = "UPDATE `car_products`SET `car_subtotal` = '". $subtotal ."',`car_quantity` = '". $count ."' WHERE `c_account` = '". $acc ."' AND `pro_number` = '". $pro_num ."'    ";
	mysql_query($sql4);
	
	
	echo '<meta http-equiv=REFRESH CONTENT=0;url=shopcar.php>';
	//echo json_decode('OK');
?>