<?php

session_start(); 
include("mysql_connect.inc.php");




$pro_name = $_POST['pro_name'];
$price = $_POST['price'];
$count=0;



$id = $_SESSION['s_account'];

//若以下$id直接用$_SESSION['c_account']將無法使用
$sql = "SELECT * FROM s_member where s_account = '$id'";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);

$sql2 = "SELECT MAX( pro_number ) FROM `products` where `s_number` = '".$row['s_number']."' ";
$result2 = mysql_query($sql2);
$row2 = mysql_fetch_array($result2);



if(isset($row2[0]))
	$max = (int)(substr($row2[0], 2, 3)) + 1;
else
	$max = 1;

$pro_number = sprintf($row['s_number']  ."%03d", $max);

//echo $pro_number ;

	$sql2 = "INSERT INTO `products` (
					`pro_number` ,
					`s_number` ,
					`pro_name` ,
					`price` ,
					`count`
					)
					VALUES (
					'". $pro_number ."', '". $row['s_number']."','". $pro_name ."', '". $price ."', '". $count ."'
					);";
			mysql_query($sql2);
	header("Location: s_istore.php");

//echo '<meta http-equiv=REFRESH CONTENT=5;url=s_istore.php>';
?>