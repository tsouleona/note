<?php
	include("mysql_connect.inc.php");

	$pid 	= $_GET['p_num'];
	$acc	= $_GET['acc'];
	$s_number	= $_GET['s_num'];
	
	//echo $pid .' '. $count .' '. $num . ' '. $acc;

		
	
//搜尋car_products哪項商品被刪除	
	$sql1 = "SELECT * FROM car_products WHERE `c_account` = '". $acc ."' AND `pro_number` = '". $pid ."'  ";
	$result1 = mysql_query($sql1);
	$row1 = mysql_fetch_array($result1);

	
	
//搜尋car	
	$sql2 = "SELECT * FROM car WHERE `c_account` = '". $acc ."' AND `s_number` = '". $s_number ."'    ";
	$result2 = mysql_query($sql2);
	$row2 = mysql_fetch_array($result2);
	
	
//  car 的 car_total  減掉  car_products 那項商品的 sub_total
	$total = $row2['car_total'];
	$subtotal = $row1['car_subtotal'];
	$total = $total-$subtotal;
	
	$sql3 = "UPDATE `car` SET `car_total` = '". $total ."' WHERE `c_account` = '". $acc ."'  AND `s_number` = '". $s_number ."'  ;";
	mysql_query($sql3);
	

	
	$sql4 = "DELETE FROM `car_products` WHERE `c_account` = '". $acc ."' AND `pro_number` = '". $pid ."'";
	mysql_query($sql4);
	
	
	$b=0;
	
	$sql6 = "DELETE  FROM `car` WHERE `s_number` = '". $s_number ."' and `c_account` = '". $acc ."' and `car_total`='".$b."'";
	mysql_query($sql6);
	
	
	echo '<meta http-equiv=REFRESH CONTENT=0;url=shopcar.php>';
	
	//echo json_decode('OK');
?>