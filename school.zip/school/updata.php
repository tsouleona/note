<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
		include("mysql_connect.inc.php");
		//使用 mysql_pconnect()而不使用mysql_connect( ) 可以省下每次重新開啟資料庫連接的時間

?>	



<?php

$sql = "select pro_number,count from products" ;  //在taipei_eat資料表中選擇所有欄位
	
	
$result = mysql_query($sql) or die(mysql_error());  // 執行SQL查詢
$row_result = mysql_fetch_array($result); //將陣列以欄位名索引


?>


	<?php $i=1; ?>
	<?php do { ?>
		

		<tr>
			<?php $p[$i] = $row_result['pro_number'];?>
			<?php $c[$i] = $row_result['count'];?>
			<?php $i++;?>
	<?php } while ($row_result = mysql_fetch_array($result));?>
		</tr>
		<?php
		
			$t = $i;
			
		?>
		
	
	<?php 
	
	for( $a=1 ; $a < $t ; $a++ )
	{
		for( $b=$a ; $b < $t ; $b++ )
		{
			if( $c[$b] > $c[$a] )
			{
				$temp = $c[$b];
				$c[$b] = $c[$a];
				$c[$a] = $temp;
				
				$temp = $p[$b];
				$p[$b] = $p[$a];
				$p[$a] = $temp;
				
			}
				
		}
	}
	?>
	<form>

	<table>
		<?php for( $a=1 ; $a<11 ; $a++ ){ ?>
			<tr>
			<td><?php echo $p[$a] ; ?></td>
			<td><?php echo $c[$a] ; ?></td>
			
		<?php } ?>
			</tr>
	</table>
</form>
	<?php
	for( $a=1 ; $a<11 ; $a++ )
	{
		$sql2 = " UPDATE popular SET pro_number='$p[$a]'WHERE rank='$a'";
		mysql_query($sql2)or die (mysql_error()); //執行sql語法
	}

?>

<?php
mysql_free_result($result); //釋放查詢結果所佔用的記憶體
?>