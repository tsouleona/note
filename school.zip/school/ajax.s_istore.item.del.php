<?php
	session_start();
	include("mysql_connect.inc.php");
	
	    $pro_number = $_GET['pro_num'];
		$s_number = $_GET['s_num'];
		
		$sql = "update `products` set `flag`='停售' WHERE  `pro_number` = '". $pro_number ."'";
		mysql_query($sql);
		
		$sql2 = "DELETE  FROM `favorite` WHERE `pro_number` = '". $pro_number ."'";
		mysql_query($sql2);
		
		$sql5 = "select * FROM `car` WHERE  `s_number` = '". $s_number ."'";
		$result5=mysql_query($sql5);
		
		while($row5 = mysql_fetch_assoc($result5))
		{
			$sql3 = "select * FROM `car_products` WHERE  `pro_number` = '". $pro_number ."'";
			$result3 =mysql_query($sql3);
			$row3 = mysql_fetch_assoc($result3);
			
			$total=$row5['car_total'];
			$subtotal=$row3['car_subtotal'];
			$total=$total-$subtotal;
			
			$sql6 = "update `car` set `car_total`='".$total."' WHERE  `s_number` = '". $s_number ."'";
			$result6 =mysql_query($sql6);
			
		}
		
		$sql4 = "DELETE FROM `car_products` WHERE `s_number` = '". $s_number ."' AND `pro_number` = '". $pro_number ."'";
		mysql_query($sql4);
		$b=0;
	
		$sql7 = "DELETE  FROM `car` WHERE `s_number` = '". $s_number ."' and `car_total`='".$b."'";
		mysql_query($sql7);
		
		echo '<meta http-equiv=REFRESH CONTENT=0;url=s_istore.php>';
		
		

?>