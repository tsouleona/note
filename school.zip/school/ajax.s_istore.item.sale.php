<?php
	session_start();
	include("mysql_connect.inc.php");
	
	    $pro_number = $_GET['pro_num'];
		$s_number = $_GET['s_num'];
		
		
		
		$sql = "update `products` set `flag`='' WHERE  `pro_number` = '". $pro_number ."'";
		mysql_query($sql);
		
		
		
		echo '<meta http-equiv=REFRESH CONTENT=0;url=s_istore.php>';
		
		

?>