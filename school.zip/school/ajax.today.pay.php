<?php
	include("mysql_connect.inc.php");

	$ord_num	= $_GET['ord_num'];
	
	$sql = "update `order_list` set `order_go` = '已付款' where `order_number`='".$ord_num."'";
	mysql_query($sql);
	
	echo '<meta http-equiv=REFRESH CONTENT=0;url=s_today.php>';

?>