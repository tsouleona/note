<!DOCTYPE html>
<?php session_start();?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>登入 - 校園點餐網</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/shop-homepage.css" rel="stylesheet">

</head>

<body>
     <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">

                <a class="navbar-brand" href="login.php">逢甲大學點餐網</a>
            </div>
		</div>
	</nav>
	

	
	
	

	<div class="col-md-4"></div>
	<div class="col-md-4">
		
	
	
		
		<div class="row">
			<div class="col-md-12">
				
				<h3 class="modal-header"><strong>服務條款請遵守以下規則：</strong></h3>
		
				<p>1.僅供逢甲大學師生以及合作商家使用</p>
				<p>2.下訂單之後，請在約定時間完成取餐</p>
				<p>3.請勿惡作劇下訂單</p>
				<p>4.交易中請確認餐點是否正確，交易完成後如有錯誤請自行負責</p>
				<p>5.若違反以上條款，本校得隨時終止其會員資格</p>	
					
			
			
		</div>
			<br></br>
			<div class="form-group">
				<div class="text-center">
					<ul class="nav nav-tabs nav-stacked">
					
						<a href="login.php"><button class="btn btn-danger">不同意</button></a>
						<a href="index.php"><button class="btn btn-success">我同意</button></a>
						<!--<input  type="submit" value="登入"  />-->
						<br></br>
						
					</ul>
				</div>
			</div>
	
		</div>
	</div>

	
	
	<div class="col-md-4"></div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>