<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
//將session清空
unset($_SESSION['id']);
echo '<strong><h1>登出中請稍後.....</h1></strong>';
echo '<meta http-equiv=REFRESH CONTENT=1;url=login.php>';
?>