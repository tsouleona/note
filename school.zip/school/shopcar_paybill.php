<?php 
	session_start();
	include("mysql_connect.inc.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>購物車 - 逢甲大學點餐網</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">
	
	<link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
	<script type="text/javascript" src="js/jquery.js" charset="UTF-8"></script>
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>	
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    
                    <li>
                        <a href="shopcar.php"><font color="white">購物車</font></a>
                    </li>
					<li>
                        <a href="favorite.php">我的最愛</a>
                    </li>
					<li>
                        <a href="shopview.php">商家總覽</a>
                    </li>
					<li>
                        <a href="today.php">今日訂單</a>
                    </li>
					<li>
                        <a href="history2.php">歷史訂單</a>
                    </li>
                </ul>
				<ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="self.php">個人設定</a>
                    </li>
					<li>
						<a href="logout.php" >登出</a>
					</li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		
		<!--<div class="col-md-4 col-md-offset-7">
			<div class="input-group">
				<input type="text" class="form-control" placeholder="請輸入關鍵字">
				<span class="input-group-btn">
					<button class="btn btn-default" type="button">
						<span class="glyphicon glyphicon-search"></span> 搜尋商店
					</button>
				</span>
			</div>
		</div>-->
    </nav>

    <!-- Page Content -->
	<?php
		$c_acc = $_GET['c_acc'];
		$s_num = $_GET['s_num'];
		$pro_num = $_GET['p_num'];
		
		$sql="select * from s_member where s_number = '".$s_num."';";
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		
		$sql2="select * from car_products where c_account = '".$c_acc."' and s_number = '".$s_num."';";
		$result2 = mysql_query($sql2);
		$row2 = mysql_fetch_array($result2);
		
		$sql3="select * from products where s_number = '".$s_num."';";
		$result3 = mysql_query($sql3);
		$row3 = mysql_fetch_array($result3);
		//echo mysql_errno() . ": " . mysql_error(). "\n" ;
	
	?>
<div class="container" id="mainPage"></br></br>
	
	<div class="row">
		<?php 
			if($row['status']=='休息中')
			{
				echo '<h1><strong>該店家為休息中</strong></h1>';
				echo '<meta http-equiv=REFRESH CONTENT=2;url=shopcar.php>';
			}
			else
			{	
		?>
				<div class="col-sm-6 col-lg-6 col-md-6">
					<div class="thumbnail">
						<div class="text-center" class="caption">
							<SCRIPT type="text/javascript"> 
							function check()
							{
								if(targetForm1.inlineRadio.value == "") 
									{
										alert("請選擇自取或外帶");
									}   
								else if(targetForm1.inlineRadio.value == "1"&&targetForm1.note.value == "")
									{
										alert("請註明外帶時間及地點");
									}
						   
								else targetForm1.submit();
							 }
							
							</SCRIPT>
										
							<form name="targetForm1" action="updata_paybill.php" class="form-horizontal" method="post">	
								<input type="hidden" name="s_num" value="<?php echo $row['s_number'];?>">	
								<h3><?php echo  $row['s_name'] ;?></h3>
								<input type="hidden" name="date" value="<?php echo date("Ymd",mktime($H =date('H')+8, $I =date('i')));?>">
								<input type="hidden" name="time" value="<?php echo date("H:i",mktime($H =date('H')+8, $I =date('i')));?>">
								<div class="text-center" class="caption">
									<table class="table table-bordered">
									
										  <thead>
											<tr>
											  <th class="text-center">商品名稱</th>
											  <th class="text-center">單價</th>
											  <th class="text-center">數量</th>
											  <th class="text-center">小計</th>
											</tr>
										  </thead>
										  <tbody>
										  
										  
									<?php 
									$sql4 = "SELECT * FROM car_products WHERE `c_account` = '". $c_acc ."'  AND   s_number = '". $s_num ."' ";
									$result4 = mysql_query($sql4);
									while($row4 = mysql_fetch_array($result4))
									{
									
										$sql5 = "SELECT * FROM products WHERE `pro_number` = '". $row4['pro_number'] ."'";
										$result5 = mysql_query($sql5);
										$row5 = mysql_fetch_array($result5);
										
									?>
												<tr class="cart_item">
													<td><?php echo $row5['pro_name']; ?></td>
													<td class="product-size">
														<?php echo $row5['price']; ?>
													</td>
													<td class="product-qty">
														<?php echo $row4['car_quantity']; ?>
													</td>
													<td class="product-price">
														<?php echo $row4['car_subtotal']; ?>
													</td>
												</tr>
									  
									<?php }?>		
										  </tbody>
									</table>
								</div>
									
									
						</div>
								 
								
							  
								<div class="form-group"class="uk-overflow-container">
									<label class="radio-inline">
									  <input type="radio" name="Radio" id="inlineRadio" value="0"> 自取
									</label>
								
									<label class="radio-inline">
										<input type="radio" name="Radio" id="inlineRadio" value="1"> 外送
									</label>
								</div> 
								
								</br>
								
								<div class="form-group"class="uk-overflow-container">
									<label class="col-md-3  control-label">備註:</label>
									<input type="text" class="form-control "size="20" name="note" id="note" placeholder="EX:中午12點送至逢甲大學資電學院">
								</div>
								
								
								<?php
									$sql6 = "SELECT * FROM car WHERE `c_account` = '". $c_acc ."'  AND   s_number = '". $s_num ."' ";
									$result6 = mysql_query($sql6);
									$row6 = mysql_fetch_array($result6);
									?>
								<div style="text-align:right;">
								<h3>總計：<span class="glyphicon glyphicon-usd" aria-hidden="true"></span>&nbsp; <?php echo $row6['car_total'] ;?> </h3>
								<br></br>
								<input type="button" class="btn btn-success"   value="確定"  onclick="check()" /> 
								 
								</div>
						</form>				   
					</div>		   
				</div>
	      <?php }?>
	</div>
</div>
	
	
	
    <!-- /.container -->

    <!-- jQuery -->

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
