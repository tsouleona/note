<?php 
	session_start();
	include("mysql_connect.inc.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>我的最愛 - 逢甲大學點餐網</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery-1.8.3.min.js" charset="UTF-8"></script>
	<script type="text/javascript">
		
		$(document).ready(
			function()
			{

			}
		);
		
		function add_car(p_num)
		{
			$.post("ajax.shopa.php",
			{
				pid: p_num, //pro_number
				num: '<?php echo $_GET['s_num'];?>', //加入購物車，接s_number
				acc: '<?php echo $_GET['c_acc'];?>', //加入購物車，接c_account
				count: $('#' +p_num).val() //數量
			},
			function(data)
			{			
				alert('OK');
			}, "json");
		}
		
		function aa(id)
		{
			$('#' + id).attr('value', parseInt($('#' + id).val()) + 1);
		}
		
		function bb(id)
		{
			var num = 1;
			if((parseInt($('#' + id).val()) - 1) < 1 )
				num = 1;
			else 
				num = parseInt($('#' + id).val()) - 1;
				
			$('#' + id).attr('value', num);
		}
		
	</script>

</head>

<body>
    <!-- Navigation -->
   <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="shopcar.php">購物車</a>
                    </li>
					<li>
                         <a href="favorite.php">我的最愛</a>
                    </li>
					<li>
                        <a href="shopview.php"><font color="white">商家總覽</font></a>
                    </li>
					<li>
                        <a href="today.php">今日訂單</a>
                    </li>
					<li>
                        <a href="history2.php">歷史訂單</a>
                    </li>
                </ul>
				<ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="self.php">個人設定</a>
                    </li>
					<li>
						<a href="logout.php" >登出</a> 
					</li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		
		<!--<div class="col-md-4 col-md-offset-7">
			<div class="input-group">
				<input type="text" class="form-control" placeholder="請輸入關鍵字">
				<span class="input-group-btn">
					<button class="btn btn-default" type="button">
						<span class="glyphicon glyphicon-search"></span> 搜尋商店
					</button>
				</span>
			</div>
		</div>-->
    </nav>

<?php
		$sql4 = "SELECT * FROM s_member WHERE s_number = '". $_GET['s_num'] ."'";
		$result4 = mysql_query($sql4);
		$row_result4 = @mysql_fetch_assoc($result4);
?>

    <!-- Page Content -->
    <div class="container" id="mainPage">
		<div class="text-center"><h1><strong><?php echo $row_result4['s_name'];?></strong></h1>
		
			<!-- Button trigger modal -->
			<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">
			  店家公告
			</button>

			<!-- Modal -->
			<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			  <div class="modal-dialog">
				<div class="modal-content">
				  <div class="modal-header">
					
					<h4 class="modal-title" id="myModalLabel">公告</h4>
				  </div>
				  <div class="text-center" class="modal-body">
						<?php echo $row_result4['announcement'];?>

						</br></br></br><span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></span>&nbsp;<?php echo $row_result4['s_phone'];?></br>
						<span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>&nbsp;<a target="_blank" href="https://www.google.com.tw/maps/place/<?php echo $row_result4['s_address'];?>"><?php echo $row_result4['s_address'];?></a>
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
				  </div>
				</div>
			  </div>
			</div></br></br>
		
		</div>
		
		<!--商品-->
	<?php
		$sql3 = "SELECT * FROM products ,s_member WHERE products.s_number=s_member.s_number AND products.s_number = '". $_GET['s_num'] ."'";
		$result3 = mysql_query($sql3);
		$row_result3 = @mysql_fetch_assoc($result3);
		
		$sql4 = "SELECT * FROM favorite WHERE `c_account` = '". $_GET['c_acc'] ."'";
		$result4 = mysql_query($sql4);
		$row_result4 = @mysql_fetch_assoc($result4);
		
		
		$sql = "SELECT * FROM products WHERE s_number='$row_result3[s_number]'";
		$result1 = mysql_query($sql);
	//	$row_result = @mysql_fetch_assoc($result);


		while($row = mysql_fetch_array($result1))
		{
			$sql2 = "SELECT * FROM car_products WHERE `c_account` = '". $_GET['c_acc'] ."' AND `pro_number` = '". $row['pro_number'] ."'";
			//echo $sql2;
			$result2 = mysql_query($sql2);
			$row2 = mysql_fetch_array($result2);
			
			if(empty($row2))
				$num = 1;
			else
				$num = $row2['car_quantity'];
	?>
			<div class="col-sm-3 col-lg-3 col-md-3">
				<div class="thumbnail">
					<div class="text-center" class="caption">
					<img src="/school/photo/<?php echo $row['s_number'];?>/<?php echo $row['pro_number'];?>.jpg" onerror="this.src='/school/photo/nothing.jpg'" width="150px" height="150px" alt="Smiley face" style="display:block; margin:auto;">
						<h3><?php echo $row['pro_name']; ?></h3>
						<input type="hidden" name="pro_number" value="<?php echo $row_result['pro_number']; ?>">
						<?php if($row['flag']=='停售'){?>
						<h3>停售</h3>
						<?php }?>
						<?php if($row['flag']!='停售'){?>
						<h3><span class="glyphicon glyphicon-usd" aria-hidden="true"></span>&nbsp;<?php echo $row['price']; ?><h3>
						<?php }?>
						
						<?php if($row['flag']=='停售' && $row_result3['status']!="休息中"){?>
						<button disabled="disabled" onclick=aa('<?php echo $row['pro_number']; ?>') class="btn btn-default" ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
						<input type="text" size="1" title="Qty" value="1" name="qty" step="1" id="<?php echo $row['pro_number']; ?>">
						<button disabled="disabled" onclick=bb('<?php echo $row['pro_number']; ?>') class="btn btn-default"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></button>
						</br></br>
						<button type="button" disabled="disabled" class="btn btn-info" data-toggle="modal" data-target="#addModal" onclick=add_car('<?php echo $row['pro_number']; ?>')><span class="glyphicon glyphicon-shopping-cart " aria-hidden="true"></span>&nbsp;加入購物車</button> 
						<button type="button" disabled="disabled" class="btn btn-warning"  onclick="javascript:location.href='ajax.addfav.php?c_acc=<?php echo $_SESSION['c_account']; ?>&pro_num=<?php echo $row['pro_number']; ?>'"><span class="glyphicon glyphicon-heart" aria-hidden="true"></span>&nbsp;加入最愛</button>
						<?php }?>
						<?php if($row['flag']=='停售' && $row_result3['status']=="休息中"){?>
						<button disabled="disabled" onclick=aa('<?php echo $row['pro_number']; ?>') class="btn btn-default" ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
						<input type="text" size="1" title="Qty" value="1" name="qty" step="1" id="<?php echo $row['pro_number']; ?>">
						<button disabled="disabled" onclick=bb('<?php echo $row['pro_number']; ?>') class="btn btn-default"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></button>
						</br></br>
						<button type="button" disabled="disabled" class="btn btn-info" data-toggle="modal" data-target="#addModal" onclick=add_car('<?php echo $row['pro_number']; ?>')><span class="glyphicon glyphicon-shopping-cart " aria-hidden="true"></span>&nbsp;加入購物車</button> 
						<button type="button" disabled="disabled" class="btn btn-warning" onclick="javascript:location.href='ajax.addfav.php?c_acc=<?php echo $_SESSION['c_account']; ?>&pro_num=<?php echo $row['pro_number']; ?>'"><span class="glyphicon glyphicon-heart" aria-hidden="true"></span>&nbsp;加入最愛</button>
						<?php }?>
						<?php if($row['flag']!='停售' && $row_result3['status']=="休息中"){?>
						<button disabled="disabled" onclick=aa('<?php echo $row['pro_number']; ?>') class="btn btn-default" ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
						<input type="text" size="1" title="Qty" value="1" name="qty" step="1" id="<?php echo $row['pro_number']; ?>">
						<button disabled="disabled" onclick=bb('<?php echo $row['pro_number']; ?>') class="btn btn-default"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></button>
						</br></br>
						<button type="button" disabled="disabled" class="btn btn-info" data-toggle="modal" data-target="#addModal" onclick=add_car('<?php echo $row['pro_number']; ?>')><span class="glyphicon glyphicon-shopping-cart " aria-hidden="true"></span>&nbsp;加入購物車</button> 
						<button type="button"  class="btn btn-warning"  onclick="javascript:location.href='ajax.addfav.php?c_acc=<?php echo $_SESSION['c_account']; ?>&pro_num=<?php echo $row['pro_number']; ?>'"><span class="glyphicon glyphicon-heart" aria-hidden="true"></span>&nbsp;加入最愛</button>
						<?php }?>
						
						<?php if($row['flag']!='停售' && $row_result3['status']!="休息中" ){?>
						<button onclick=aa('<?php echo $row['pro_number']; ?>') class="btn btn-default" ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
						<input type="text" size="1" title="Qty" value="1" name="qty" step="1" id="<?php echo $row['pro_number']; ?>">
						<button onclick=bb('<?php echo $row['pro_number']; ?>') class="btn btn-default"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></button>
						</br></br>
						<button type="button" class="btn btn-info" data-toggle="modal" data-target="#addModal" onclick=add_car('<?php echo $row['pro_number']; ?>')><span class="glyphicon glyphicon-shopping-cart " aria-hidden="true"></span>&nbsp;加入購物車</button> 
						<button type="button" class="btn btn-warning" onclick="javascript:location.href='ajax.addfav.php?c_acc=<?php echo $_SESSION['c_account']; ?>&pro_num=<?php echo $row['pro_number']; ?>'"><span class="glyphicon glyphicon-heart" aria-hidden="true"></span>&nbsp;加入最愛</button>
						<?php }?>
						
						
					</div>
				</div>
			</div>
	<?php
		
		}
		
	?>

	<!-- Modal -->
				<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
						<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
								<h4 class="modal-title" id="myModalLabel">已加入購物車</h4>
							  </div>
						  
						</div>
				  </div>
				</div>
				
			<!--	<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
						<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
								<h4 class="modal-title" id="myModalLabel">已加入我的最愛</h4>
							  </div>
						  
						</div>
				  </div>
				</div>
				<div class="modal fade" id="moveModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
						<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
								<h4 class="modal-title" id="myModalLabel">已移除我的最愛</h4>
							  </div>
						  
						</div>
				  </div>
				</div>
				-->
    
    <!-- /.container -->

</body>

</html>
