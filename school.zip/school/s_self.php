<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>個人設定 - 逢甲大學點餐網</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">

	<link href="bootstrap.css" rel="stylesheet">
	<link href="bootstrap-switch.css" rel="stylesheet">

</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="s_index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
						<a href="s_istore.php">我的商店</a>
					</li>
                   <li>
                        <a href="s_shopview.php">商家總覽</a>
					</li>
					<li>
                        <a href="s_today.php">今日訂單</a>
					</li>
					<li>
                        <a href="s_history2.php">歷史訂單</a>
					</li>
				</ul>
                <ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="s_self.php"><font color="white">個人設定</font></a>
					</li>
					<li>
						<a href="logout.php" >登出</a>
					</li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <?php session_start(); 
					include("mysql_connect.inc.php");
					$id = $_SESSION['s_account'];
					
					$sql = "SELECT * FROM s_member where s_account = '$id'";
					$result = mysql_query($sql);
					$row = mysql_fetch_row($result);
					//echo mysql_errno() . ": " . mysql_error(). "\n"	
	?>
	
	
	

    <!-- Page Content -->
    <div class="container" id="mainPage">
	<div class="col-sm-4 col-lg-4 col-md-4"></div>
		<div align="center" class="col-sm-4 col-lg-4 col-md-4">
			<div class="thumbnail">
				<table class="table">
				   <thead>
					  <tr>
						 <th class="text-center">商家資料</th>
					  </tr>
				   </thead>
				   <tbody>
					  <tr>
						 <td class="text-center"><span class="glyphicon   glyphicon-user " aria-hidden="true"></span>&nbsp;<?php echo $row[4];?></td>
					  </tr>
					  <tr>
						 <td class="text-center"><span class="glyphicon   glyphicon-credit-card " aria-hidden="true"></span>&nbsp;<?php echo $row[0];?></td>
					  </tr>
					  <tr>
						 <td class="text-center"><span class="glyphicon glyphicon-phone" aria-hidden="true"></span>&nbsp;<?php echo $row[5];?></td>
					  </tr>
					  <tr>
						 <td class="text-center"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>&nbsp;<?php echo $row[7];?></td>
					  </tr>
					  <tr><td class="text-center">
					  
					  
					
							<!-- Button trigger modal -->
							<form name="targetForm1" action="s_self_update_phone.php" class="form-horizontal" method="post">
							<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-floppy-open " aria-hidden="true"></span>&nbsp;
							  修改手機
							</button>

							<!-- Modal -->
							<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							  <div class="modal-dialog">
								<div class="modal-content">
								  <div class="modal-header">
									<h4 class="modal-title" id="myModalLabel">請輸入新的手機號碼</h4>
								  </div>
			
								  <div class="modal-body">
								  
									<div class="text-center" class="caption">
											<div class="form-group">
		
												<input type="text" class="form-control" id="c_phone" name="s_phone" value="<?php echo $row[5];?>"/>
											
											</div>
									</div>
								  </div>
								  
								
								  
								  <div class="modal-footer">
									<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-remove " aria-hidden="true"></span>&nbsp;取消</button>
										<!--<input  type="submit" value="summit"  />-->
									<input type="button" class="btn btn-success"   value="儲存"  onclick="submit()" /> 
									 <script type="text/javascript"> 
									function submit()
									{
										   
										targetForm1.submit();
									}		
									</script>
										
										
									<!--<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-remove " aria-hidden="true"></span>&nbsp;儲存</button>-->
								
								  </div>
								</div>
							  </div>
							</div>
							</form>
							</br>
							<!-- Button trigger modal -->
							<form name="targetForm1" action="s_self_update_email.php" class="form-horizontal" method="post">
								<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal2"><span class="glyphicon glyphicon-floppy-open " aria-hidden="true"></span>&nbsp;
								  修改Email
								</button>

								<!-- Modal -->
								<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
								  <div class="modal-dialog">
									<div class="modal-content">
									  <div class="modal-header">
										<h4 class="modal-title" id="myModalLabel2">請輸入新的Email</h4>
									  </div>
									  <div class="modal-body">
											<div class="text-center" class="caption">
												<div class="form-group">
													<input type="text" class="form-control" id="c_Email" name="s_Email" value="<?php echo $row[7];?>"/>
												</div> 
											</div>
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-remove " aria-hidden="true"></span>&nbsp;取消</button>
										<input type="button" class="btn btn-success"   value="儲存"  onclick="submit()" /> 
										 <script type="text/javascript"> 
										function submit()
										{
											   
											targetForm1.submit();
										}		
										</script>
										<!--<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-saved " aria-hidden="true"></span>&nbsp;儲存</button>-->
									  </div>
									</div>
								  </div>
								</div>
							</form>
						</td>
					  </tr>
				   </tbody>
				</table>
			</div>
		<!--
			<h3>通知
			<div class="btn-group btn-toggle"> 
				<button class="btn btn-lg btn-default"><span class="glyphicon glyphicon-volume-up" aria-hidden="true"></span></button>
				<button class="btn btn-lg btn-default"><span class="glyphicon glyphicon-volume-off" aria-hidden="true"></span></button>
			</div></h3>
			
			<h3>震動
			<div class="btn-group btn-toggle"> 
				<button class="btn btn-lg btn-default"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span></button>
				<button class="btn btn-lg btn-default"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
			</div></h3>

			<h3>LED
			<div class="btn-group btn-toggle"> 
				<button class="btn btn-lg btn-default"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></button>
				<button class="btn btn-lg btn-default"><span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span></button>
			</div></h3>
		-->
		</div>	
    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>