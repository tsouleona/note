<?php 
	session_start();
	include("mysql_connect.inc.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>購物車 - 逢甲大學點餐網</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">
	
	<!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery-1.8.3.min.js" charset="UTF-8"></script>
	

	
	<script type="text/javascript">
		
		$(document).ready(
			function()
			{

			}
		);
		
		function del_car(p_num,acc , s_num)
		{
			$('#' + p_num).hide(500);
			
			$.post("ajax.shopa.del.php",
			{
				pid: p_num,  //pro_number
				acc: acc,    //c_account
				num: s_num   //s_number
			},
			function(data)
			{
			}, "json");
			
			
			
			
			/*function del_allcar(acc , s_num)
			{
			
			
			
			$.post("ajax.shopa.del.all.php",
			{
				//pid: p_num,  //pro_number
				acc: acc,    //c_account
				num: s_num   //s_number
			},
			function(data)
			{
			}, "json");*/
			
			
		//	location.reload('shopcar.php');
		
		}
		function aa(id,acc,coun)
		{
			$.post("ajax.shopcar.add.php",
			{
				p_num:id,
				c_acc:acc,
				count:coun
				
			},
			function(data)
			{
				alert('OK');
			}, "json");
		}
		
	
		function bb(id,acc,coun)
		{
			$.post("ajax.shopcar.minus.php",
			{
				p_num:id,
				c_acc:acc,
				count:coun
				
			},
			function(data)
			{
				alert('OK');
			}, "json");
		}
		

	</script>
	
	
	

</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    
                    <li>
                        <a href="shopcar.php"><font color="white">購物車</font></a>
                    </li>
					<li>
                        <a href="favorite.php">我的最愛</a>
                    </li>
					<li>
                        <a href="shopview.php">商家總覽</a>
                    </li>
					<li>
                        <a href="today.php">今日訂單</a>
                    </li>
					<li>
                        <a href="history2.php">歷史訂單</a>
                    </li>
                </ul>
				<ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="self.php">個人設定</a>
                    </li>
					<li>
						<a href="logout.php" >登出</a>
					</li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		
		<!--<div class="col-md-4 col-md-offset-7">
			<div class="input-group">
				<input type="text" class="form-control" placeholder="請輸入關鍵字">
				<span class="input-group-btn">
					<button class="btn btn-default" type="button">
						<span class="glyphicon glyphicon-search"></span> 搜尋商店
					</button>
				</span>
			</div>
		</div>-->
    </nav>

    <!-- Page Content -->
	
    <div class="container" id="mainPage"></br></br>
	
		<div class="row">
		
		
	
			<?php
			//$sql1 = "SELECT * FROM car,s_member where car.s_number=s_member.s_number";
			//$result1 = mysql_query($sql1);
			//$row_result1 = mysql_fetch_assoc($result1);
			//echo $result1['s_name'] ;
			//echo $row_result1['s_name'] ;
			//echo $row_result1[0] ;
			$id = $_SESSION['c_account'];
			$sql = "SELECT * FROM car,s_member where car.s_number=s_member.s_number AND car.c_account='".$id."'"; //紀錄誰登錄
			$result = mysql_query($sql);
			//$row_result = mysql_fetch_assoc($result);
			//echo mysql_errno() . ": " . mysql_error(). "\n"	;
			
			//if($row = mysql_fetch_array($result)==NULL)
			//{
				//echo "<h1>尚未有任何商品加入購物車</h1>";
			//}
			//else
			//{
					while($row = mysql_fetch_array($result))
				{
				//	print_r($row);
				if($row['status']=='營業中')
				{
			?>
				
					<div class="col-sm-6 col-lg-6 col-md-6">
						<div class="thumbnail">
							<div class="text-center" class="caption">
								<table class="table table-bordered">
								<caption class="text-center"><h3><strong><?php  echo  $row['s_name']; ?></h3></caption>
								  <thead>
									<tr>
									  <th class="text-center">刪除</th>
									  <th class="text-center" style="display:none">商品編號</th>
									  <th class="text-center">商品名稱</th>
									  <th class="text-center">單價</th>
									  <th class="text-center">數量</th>
									  <th class="text-center">小計</th>
									</tr>
								  </thead>
								  <tbody>
							<?php
								$sql2 = "SELECT * FROM car_products WHERE `c_account` = '". $row['c_account'] ."'  AND   s_number = '". $row['s_number'] ."' ";
								$result2 = mysql_query($sql2);
						        
					
										while($row2 = mysql_fetch_array($result2))
										{
										//	echo $sql2;
										//	print_r($row2);
											$sql3 = "SELECT * FROM products WHERE `pro_number` = '". $row2['pro_number'] ."'";
											$result3 = mysql_query($sql3);
											$row3 = mysql_fetch_array($result3);
										//	print_r($row3);
										
									?>
											<tr class="cart_item" id="<?php echo $row2['pro_number']; ?>">
												<td  align="center" class="product-remove">
													<button onclick="javascript:location.href='ajax.shopa.del.php?&p_num=<?php echo $row2['pro_number']; ?>&acc=<?php echo $row['c_account']  ;?>&s_num=<?php echo $row['s_number'] ;?>'" class="btn btn-danger btn-md" data-toggle="modal"><span class="glyphicon glyphicon-remove" aria-hidden="true" ></span></button>
												</td>
												<td style="display:none"><?php echo $row2['pro_number']; ?></td>
												<td  align="center"><?php echo $row3['pro_name']; ?></td>
												<td  align="center" class="product-size"><span class="glyphicon glyphicon-usd" aria-hidden="true"></span><?php echo $row3['price']; ?></td>
												
												<td  align="center">
												
												<div class="row"><button onclick="location.href='ajax.shopcar.add.php?p_num=<?php echo $row2['pro_number']; ?>&c_acc=<?php echo $row['c_account']; ?>&coun=<?php echo $row2['car_quantity']; ?>&s_num=<?php echo $row['s_number'] ;?>'" class="btn btn-default" ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button></div>
												
												<div class="row"><h4 id="<?php echo $row2['pro_number']; ?>"><?php echo $row2['car_quantity']; ?></h4></div>
												
												<div class="row"><button onclick="location.href='ajax.shopcar.minus.php?p_num=<?php echo $row2['pro_number']; ?>&c_acc=<?php echo $row['c_account']; ?>&coun=<?php echo $row2['car_quantity']; ?>&s_num=<?php echo $row['s_number'] ;?>'" class="btn btn-default"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></button></div>	
												<?php //echo $row2['car_quantity']; ?> </td>	
												
																				
												<td  align="center" class="product-price"><span class="glyphicon glyphicon-usd" aria-hidden="true"></span><?php echo $row2['car_subtotal']; ?></td>
											</tr>
									<?php
										
										}
										mysql_free_result($result2);
									?>
								  </tbody>
								</table>
								<!-- del_allcar('<?php //echo $row['c_account']  ?>','<?php //echo $row['s_number'] ?>') -->
								
								<button  onclick="javascript:location.href='ajax.shopa.del.all.php?s_num=<?php echo $row['s_number']; ?>&c_acc=<?php echo $row['c_account']; ?>'" class="btn btn-danger" data-toggle="modal" data-target="#moveModal"><span class="glyphicon   glyphicon-remove-sign " aria-hidden="true"></span>&nbsp;刪除訂單</button>&nbsp;	
								<button onclick="javascript:location.href='shopa.php?s_num=<?php echo $row['s_number']; ?>&c_acc=<?php echo $row['c_account']; ?>'" class="btn btn-primary" role="button"><span class="glyphicon   glyphicon-shopping-cart " aria-hidden="true"></span>&nbsp;繼續購物</button>&nbsp;	
								<!-- Button trigger modal -->

									<button onclick="javascript:location.href='shopcar_paybill.php?s_num=<?php echo $row['s_number']; ?>&c_acc=<?php echo $row['c_account']; ?>'" type="button" class="btn btn-success" ><span class="glyphicon   glyphicon-check " aria-hidden="true"></span>&nbsp;進入結帳</button>
	<?php
				}
				else
				{
					$sql4="Delete  from `car` where `s_number` ='".$row['s_number']."' AND `c_account`='".$row['c_account']."';";
					mysql_query($sql4);
					$sql5="Delete  from `car_products` where `s_number` ='".$row['s_number']."' AND `c_account`='".$row['c_account']."';";
					mysql_query($sql5);
				}
				
	?>			
								
							</div>
						</div>
					</div>
				<?php
					}
					
				?>
				
			<?php //}?>
		
		</div>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<div class="thumbnail">
					<div class="text-center" class="caption">
						
						<p align="left">
							註：</br>
								若購物車不在頁面內</br>
								1.表示該店家為休息中。</br>
								2.您尚未有任何商品加入購物車。</br>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>



		
	
	<!-- Modal -->
	<div class="modal fade" id="moveone" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		  <div class="modal-dialog">
				<div class="modal-content">
					  <div class="modal-header">
						<h4 class="modal-title" id="myModalLabel">確定要刪除該項目嗎？</h4>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon   glyphicon-remove " aria-hidden="true"></span>&nbsp;取消</button>
						<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon   glyphicon-ok " aria-hidden="true"></span>&nbsp;確定</button>
					  </div>
				</div>
				
		  </div>
	  
	</div>
	<!-- Modal -->
	<?php /*<div class="modal fade" id="moveModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		  <div class="modal-dialog">
				<div class="modal-content">
					  <div class="modal-header">
						<h4 class="modal-title" id="myModalLabel">確定要刪除訂單嗎？</h4>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon   glyphicon-remove " aria-hidden="true"></span>&nbsp;取消</button>
						<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon   glyphicon-ok " aria-hidden="true"></span>&nbsp;確定</button>
					  </div>
				</div>
				
		  </div>
	  */?>
	</div>
	
	
	
	
	

    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
