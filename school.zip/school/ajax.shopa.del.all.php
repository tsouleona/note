<?php
	include("mysql_connect.inc.php");

	//$pid 	= $_POST['pid'];
	$acc	= $_GET['c_acc'];
	$num	= $_GET['s_num'];
	
	
	//echo  $num . ' '. $acc;
	
	$sql = "DELETE FROM `car` WHERE `c_account` = '". $acc ."' AND `s_number` = '". $num ."'    ";
	mysql_query($sql);
	
	
	$sql2 = "DELETE FROM `car_products` WHERE `c_account` = '". $acc ."' AND `s_number` = '". $num ."'    ";
	mysql_query($sql2);
	
	echo '<meta http-equiv=REFRESH CONTENT=0;url=shopcar.php>';
	//echo json_decode('OK');
?>