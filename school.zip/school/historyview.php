<!DOCTYPE html>
<?php
	session_start();
	include("mysql_connect.inc.php");
?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>歷史訂單 - 校園點餐網</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">


</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">逢甲大學點餐網</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li>
                        <a href="shopcar.php">購物車</a>
					</li>
					<li>
                        <a href="favorite.php">我的最愛</a>
					</li>
					<li>
                        <a href="shopview.php">商家總覽</a>
					</li>
					<li>
                        <a href="today.php">今日訂單</a>
					<li>
                        <a href="history2.php"><font color="white">歷史訂單</font></a>
					</li>
				</ul>
                <ul class="nav navbar-nav navbar-right">
					<li>
                        <a href="self.php">個人設定</a>
					</li>
					<li>
						<a href="logout.php" >登出</a>
                    </li>
                </ul>
				
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
		
    </nav>
	<?php 
		$ord_num = $_GET['ord_num'];
		$s_name = $_GET['s_name'];
	
	?>
	
	<div class="text-center"><h1><strong><?php echo $ord_num;?><?php echo $s_name;?></strong></h1></div>
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-sm-6 col-lg-6 col-md-6" >
			
				<div class="text-center" >
					<table class="table table-bordered">
						
						<thead>
							<tr>
							
								<th class="text-center">名稱</th>
								<th class="text-center">數量</th>
								<th class="text-center">單價</th>
								<th class="text-center">小計</th>
								<th class="text-center">加入我的最愛</th>
							  
							  
							</tr>
						</thead>
						<?php
							$sql="select * from order_products where order_number='".$ord_num."' ;";
							$result = mysql_query($sql);
							//$row = mysql_fetch_assoc($result);
							
							while($row = mysql_fetch_assoc($result))
							{
								$sql2 = "select * from products where pro_number = '".$row['pro_number']."';";
								$result2 = mysql_query($sql2);
							    $row2 = mysql_fetch_assoc($result2);
							
						?>
								  <tbody>
										<tr>
											<td>
												<h5><?php echo $row2['pro_name'];?></h5>
											</td>
											<td>
												<h5><?php echo $row['order_quantity'];?></h5>	
											</td>
											
											<td >
												<h5><?php echo $row['price'];?></h5>
											</td>
											<td >
												<h5><?php echo $row['order_subtotal'];?></h5>
											</td>
											<td >
							                <?php if($row2['flag']=='停售'){?>
												<button type="button" disabled="disabled" class="btn btn-warning"  onclick="javascript:location.href='ajax.addfav.php?c_acc=<?php echo $_SESSION['c_account']; ?>&pro_num=<?php echo $row2['pro_number']; ?>'"><span class="glyphicon glyphicon-heart" aria-hidden="true"></span>&nbsp;加入最愛</button>
											<?php }?>
											<?php if($row2['flag']!='停售'){?>
												<button type="button" class="btn btn-warning"  onclick="javascript:location.href='ajax.historyview.addfav.php?c_acc=<?php echo $_SESSION['c_account']; ?>&pro_num=<?php echo $row2['pro_number']; ?>'"><span class="glyphicon glyphicon-heart" aria-hidden="true"></span>&nbsp;加入最愛</button>
											<?php }?>
											</td>
											
										</tr>
										
									
										
								  </tbody>
								  
						  <?php }?>
					</table>
					
				</div>
			
		</div>
	</div>
	<?php
		$sql3="select * from order_list where order_number='".$ord_num."' ;";
		$result3 = mysql_query($sql3);
		$row3 = mysql_fetch_assoc($result3);

	?>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-5">
				<?php
					if($row3['order_state']=="不接受"){
				?>
				<h4>取消原因:&nbsp;<?php echo $row3['note']?></h4>
				<?php }?>
				<h4 class="pull-right">總計：<span class="glyphicon glyphicon-usd" aria-hidden="true"></span>&nbsp;<?php echo $row3['order_total'];?></h4>
			</div>
		</div>
	</div>
	<!-- Modal -->
				<!--<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
						<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
								<h4 class="modal-title" id="myModalLabel">已加入我的最愛</h4>
							  </div>
						  
						</div>
				  </div>
				</div>-->
				<div class="modal fade" id="moveModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
						<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
								<h4 class="modal-title" id="myModalLabel">已移除我的最愛</h4>
							  </div>
						  
						</div>
				  </div>
				</div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
