<meta charset="UTF-8">
<form method="post" action "<?php echo $_SERVER['PHP_SELF']; ?>" >
<?php
    session_start();
    if(!$_POST['year']==null && !$_POST['month']==null) {
    $_SESSION["year"] = $_POST['year'];
    $_SESSION["month"] = $_POST['month'];
    }
?>
請選擇日期(年/月):
<select name='year'>
    <?php
        createNumOption( (int)$_SESSION["year"],2000,2050 );   //加入(int)把string轉成int,統一選項的輸出type
    ?>
</select>
/
<select name='month'>
    <?php
        createNumOption( (int)$_SESSION["month"],1,12 );
    ?>
</select>
<input type="submit" value="確定">
</form>
<?php
function createNumOption($chosen_num, $start_num, $end_num) {
    for($i=$start_num; $i<=$end_num; $i++) {
            if($i==$chosen_num){
                echo "<option selected='$chosen_num'>$chosen_num</option>";
            }
            else {
                echo "<option value='$i'>$i</option>";    
            }
        }
    
}


?>