<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>    
<body style="text-align:left">
    <form method="post" action="Registered_check.php">  
        Username:<input type="text" name="id"></br>
        Password:<input type="password" name="pw"></br>
        <input type="submit" value="Sign In">
    </form>
</body>
</html>