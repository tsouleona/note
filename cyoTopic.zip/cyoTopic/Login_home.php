<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>    
<body style="text-align:left">
    <form method="post" action="Login_check.php">
        Username:<input type="text" name="id"></br>
        Password:<input type="password" name="pw"></br>
        <input type="submit" value="Sign In">
        <input type="reset" value="Reset">
    </form>
    <input type="button" value="Sign Up" onclick="location.href='Registered_home.php'"
</body>
</html>