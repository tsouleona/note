<?php  session_start();
    $firstday = date("w",mktime(0,0,0,$_SESSION["month"],1,$_SESSION["year"]));
    $totaldays  = date("t",mktime(0,0,0,$_SESSION["month"],1,$_SESSION["year"]));

    echo "<table border='1px'>";
    echo "<tr height=20>";
    $dayofweek = array( 'Monday', 'Tuesday', 'Wednesday','Thursday','Friday', 'Saturday', 'Sunday');
    for($i=1 ; $i<=7 ; $i++){
        echo "<th width=150 align=center>".$dayofweek[$i-1]."</th>";    //先畫出最上面星期一到星期日的標題
    }
    echo "</tr>";
    $fin_week = ceil( ($firstday+$totaldays-1)/7 );     //計算這個月總共會用到幾週
    for($i_week=1 ; $i_week<=$fin_week ; $i_week++) {   //最外層是跑第幾週
        echo "<tr height=20>";
        //畫日期
        for ($i_day=1 ; $i_day<=7 ; $i_day++) {
            $current_box = $i_day + 7*($i_week-1);   //計算當前的格子是第幾格
            echo "<th align=center>";
                if( $current_box >= $firstday && $current_box <= $totaldays +$firstday -1 ) { //如果格子是在開始日與結束日之間,開始填入日期
                    $day = $current_box - $firstday + 1;
                    echo (int)$_SESSION["month"],"/",$day;  //印出日期當超連結文字,並且傳送日期
                }
            echo "</th>";
        }
        echo "</tr>";
        //畫格子,判斷同日期,只是在日期畫完一行後接著畫
        echo "<tr height=50>";
        for ($i_day=1 ; $i_day<=7 ; $i_day++){
            $current_box = $i_day + 7*($i_week-1);
            echo "<th align=center>";
                if( $current_box >= $firstday && $current_box <= $totaldays +$firstday -1 ) {
                    $day = $current_box - $firstday + 1;
                    echo "<a    href='Information_day.php?day=$day'>","當日支出名細","</a>";
                }
            echo "</th>";
        }
        echo "</tr>";
    }
    echo "</table>";

?>
