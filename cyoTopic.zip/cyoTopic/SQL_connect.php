<?php
// 伺服器位置、帳號、密碼、資料庫
$dbhost = 'localhost:3306';
$dbuser = 'root';
$dbpass = '';
$dbname = 'cyoPHP';
$link = mysql_connect($dbhost,$dbuser,$dbpass) or die(mysql_error("伺服器無法連結！"));
$result = mysql_query("set names utf8",$link);
mysql_selectdb($dbname,$link);

// if($link)
//     echo "ok~~~~~</br>";
?>