<?php
header("content-type:text/html; charset=utf-8");
$link = mysql_connect("127.0.0.1", "root", "") or die("mysql_coonect() 資料庫無法連結！");
mysql_select_db("chungyoPHP",$link) or die("mysql_select_db() 資料庫無法連結！");

// 測試叫出所有umane資料
$result = mysql_query("SELECT * FROM members");
while($row = mysql_fetch_array($result)){
  echo $row['uname']."<br>";
}
echo "ok";

?>