<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Mainpage</title>
</head>    
<body style="text-align:left">
       <?php session_start();
            if(!$_SESSION["id"] == null) {
                echo $_SESSION["id"],",welcome!</br>";
                date_default_timezone_set('Asia/Taipei');
                $datetime= date("Y/m/d H:i:s");
                include "Option_date.php";
                include "Information_month.php";
            }
            else {
                echo "請先登入系統!";
                echo "<meta http-equiv=REFRESH CONTENT=3;url=Login_home.php>";
            }
        ?>
</body>
</html>