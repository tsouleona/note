<?php    
    include("SQL_connect.php");
    header("Content-Type:text/html; charset=utf-8");
    $id = $_POST['id'];  //把帳號存成id
    $pw = $_POST['pw'];    //把密碼存成pw
    $sql = "SELECT count(uname) FROM members WHERE uname = '$id'"; //輸入sql指令:"從member表格中尋找是不是有資料等於註冊帳號"
    $result = mysql_query($sql);    //丟進sql去處理
    $row = mysql_fetch_row($result);    //用$row[0]來儲存表格內已存在帳號與註冊帳號相同名稱的數量, 1=已使用, 0=未使用
    //echo $row[0];
    //echo "$id,$pw";
    if($id != null && $pw != null  && $row[0] == 0) {   //判斷帳號、密碼是否非空白,帳號名稱沒有被使用過
         $sql = "INSERT INTO members(uname,upw) VALUES ('$id','$pw')";  //輸入sql指令:"將申請的帳號,密碼丟入members表單"
         mysql_query($sql); //丟進sql去處理
         $sql = "CREATE TABLE table_$id(id int(255) UNSIGNED AUTO_INCREMENT,
                                        year int(255),
                                        month int(255),
                                        day int(255),
                                        type varchar(255),
                                        item varchar(255),
                                        price int(255) UNSIGNED,
                                        invoce int(3) UNSIGNED,
                                        remark text,
                                        PRIMARY KEY (id)
                                        )"; //輸入sql指令:"創建table" type=1食 2衣 3住 4行 5其它
         mysql_query($sql); //丟進sql去處理
         echo "註 冊 成 功 ! (啪啪啪)";
         echo "$sql";
        // echo '<meta http-equiv=REFRESH CONTENT=1;url=Login_home.php>';   //跳轉頁面到登入首頁
    } 
    elseif($row[0] ==1) {   //判斷帳號名稱已經被使用過
        echo "菜市場名被用過了喔~";
        //echo '<meta http-equiv=REFRESH CONTENT=3;url=Registered_home.php>'; //跳轉頁面到註冊首頁
    }
    else {  //判斷帳號或密碼有空白
        echo "帳號或密碼不能空白";
        //echo '<meta http-equiv=REFRESH CONTENT=3;url=Registered_home.php>'; //跳轉頁面到註冊首頁
    }

?>
