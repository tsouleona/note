<?php 
    header("Content-Type:text/html; charset=utf-8");
    include("SQL_connect.php"); //連結到資料庫
    $id = $_POST['id'];  //把帳號存成id
    $pw = $_POST['pw'];    //把密碼存成pw
    $sql = "SELECT * FROM members WHERE uname = '$id'"; //輸入sql指令:"從member表格中尋找是不是有資料等於輸入帳號的那行資料"
    $result = mysql_query($sql);    //丟進sql去處理
    $row = mysql_fetch_row($result);    //把uname='$id'的那行資料存成$row

    if($id != null && $pw != null  && $row[2] == $pw)   //如果帳號、密碼不為空,且密碼等於$row所存的第二欄(pw)資料
    {   
        session_start();
        $_SESSION['id'] = $id;   //把$uname在伺服器存成登入的帳號
        echo '登入成功！</br>';      //顯示登入成功
        date_default_timezone_set('Asia/Taipei');   //調整時區到台灣
        $datetime= date("Y/m/d H:i:s"); //紀錄目前時間
        $_SESSION['year'] = date("Y");  //紀錄登入的年月,到時候傳到個人主頁面先顯示當時的年月
        $_SESSION['month'] = (int)date("m");
        echo gettype($_SESSION['month']);
        $sql = "UPDATE `members` SET `login_time`='$datetime' WHERE `uname`='$id'"; //紀錄最新登入時間,輸入sql指令:"把現在時間存入member表格中,uname=帳號那行的login_time這欄位"
        $result = mysql_query($sql);    //丟進sql去處理
        echo $_SESSION['month'];
        echo '<meta http-equiv=REFRESH CONTENT=1;url=Mainpage.php>';   //跳轉頁面到個人首頁
    }
    else
    {
        echo "登入失敗，請輸入正確的帳號與密碼。";  //登入錯誤訊息
        echo "<meta http-equiv=REFRESH CONTENT=1;url=Login_home.php>";  //跳轉回登入頁面
    }
?>
